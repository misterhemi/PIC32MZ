/*
 * File name: usb_dma.c for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#include <xc.h>
#include <sys/attribs.h>
#include <sys/kmem.h>
#include "main.h"
#include "dma.h"
#include "usb_dma.h"
#include "InterruptMask.h"

void __attribute__((interrupt(ipl5srs), at_vector(_USB_DMA_VECTOR), no_fpu, nomips16)) USBDMA_Handler(void){
    
    if(USBDMAINTbits.DMA1IF == 1){ // USB DMA 1 assigned to Endpoint 3
        led_4g = ~led_4g;
        
        DCH1CSIZbits.CHCSIZ = ep1rbc;
        
        // CHEN: Channel Enable bit(2)
        // 1 = Channel is enabled 
        // 0 = Channel is disabled    
        DCH1CONbits.CHEN = 1; // DMA Channel 1 is Enabled.
        
        
        // CFORCE: DMA Forced Transfer bit
        // 1 = A DMA transfer is forced to begin when this bit is written to a '1' 
        // 0 = This bit always reads '0'
        DCH1ECONbits.CFORCE = 1;
        
        USBDMAINTbits.DMA2IF = 0;
    }
    
    if(USBDMAINTbits.DMA3IF == 1){ 
        
        
        USBDMAINTbits.DMA3IF = 0;
    }
    
    if(USBDMAINTbits.DMA4IF == 1){ 
        
        
        USBDMAINTbits.DMA4IF = 0;
    }
    
    if(USBDMA1Cbits.DMAERR){
        // Clear the error
        USBDMA1Cbits.DMAERR = 0;
    }
    
    if(USBDMA2Cbits.DMAERR){
        // Clear the error
        USBDMA2Cbits.DMAERR = 0;
    }
    
    IFS4CLR = _IFS4_USB_DMA_EVENT_MASK;
    led_4r = ~led_4r;
}

void initUSBDMA(){
    
    IEC4bits.USBDMAIE = 0;  // Disable USB DMA interrupt.
    IFS4CLR = _IFS4_USB_DMA_EVENT_MASK;
    
    USBDMAINT = 0x00;       // Clear Channels 1-8 USB DMA Interrupt Flags
    
    // Set the USB DMA Interrupt Priority and Sub-Priority Levels
    IPC33bits.USBDMAIP = 5;
    IPC33bits.USBDMAIS = 3;
    
    // USBDPBFD: USB Double Packet Buffer Disable Register
    USBDPBFD = 0x00FF00FF;
    
    // DMABRSTM<1:0>: DMA Burst Mode Selection bit
    // 11 = Burst Mode 3: INCR16, INCR8, INCR4 or unspecified length 
    // 10 = Burst Mode 2: INCR8, INCR4 or unspecified length
    // 01 = Burst Mode 1: INCR4 or unspecified length
    // 00 = Burst Mode 0: Bursts of unspecified length
    USBDMA1Cbits.DMABRSTM = 3;
    
    // DMAEP<3:0>: DMA Endpoint Assignment bits
    // These bits hold the endpoint that the DMA channel is assigned to. Valid values are 0-7.
    USBDMA1Cbits.DMAEP = 1; // OUT Endpoint 1
    
    // DMAREQEN: Endpoint DMA Request Enable bit
    // 1 = DMA requests are enabled for this endpoint 
    // 0 = DMA requests are disabled for this endpoint
    // USBIENCSR0 for TX endpoint, USBIENCSR1 for RX endpoint
    USBE1CSR1bits.DMAREQEN = 1;
    
    //**************************************************************************
    // DMAREQMD: DMA Request Mode Selection bit 
    // 1 = DMA Request Mode 1
    // 0 = DMA Request Mode 0
    // USBIENCSR0 for TX endpoint, USBIENCSR1 for RX endpoint
    USBE1CSR1bits.DMAREQMD = 0;
    //USBE3CSR1bits.DMAREQMD = 0;
    
    // DMAMODE: DMA Transfer Mode bit 
    // 1 = DMA Mode1 Transfers
    // 0 = DMA Mode0 Transfers
    USBDMA1Cbits.DMAMODE = 0;
    //**************************************************************************
    
    // DMADIR: DMA Transfer Direction bit
    // 1 = DMA Read (TX endpoint)
    // 0 = DMA Write (RX endpoint)
    USBDMA1Cbits.DMADIR = 0;
    
    // DMAADDR<31:0>: DMA Memory Address bits
    // This register identifies the current memory address of the corresponding 
    // DMA channel. The initial memory address written to this register during 
    // initialization must have a value such that its modulo 4 value is equal 
    // to '0'. The lower two bits of this register are read only and cannot be 
    // set by software. As the DMA transfer progresses, the memory address will 
    // increment as bytes are transferred.
    USBDMA1Abits.DMAADDR = KVA_TO_PA(&USB_EP1_buffer);   // USB DMA1 memory address.
    
    // TXEDMA: TX Endpoint DMA Assertion Control bit
    // 1 = DMA_REQ signal for all IN endpoints will be deasserted when MAXP-8 bytes 
    // have been written to an endpoint. This is Early mode.
    // 0 = DMA_REQ signal for all IN endpoints will be deasserted when MAXP bytes 
    // have been written to an endpoint. This is Late mode.
    USBOTGbits.TXEDMA = 0;
    
    // RXEDMA: RX Endpoint DMA Assertion Control bit
    // 1 = DMA_REQ signal for all OUT endpoints will be deasserted when MAXP-8 bytes 
    // have been written to an endpoint. This is Early mode.
    // 0 = DMA_REQ signal for all OUT endpoints will be deasserted when MAXP bytes 
    // have been written to an endpoint. This is Late mode.
    USBOTGbits.RXEDMA = 0;
    
    // DMAIE: DMA Interrupt Enable bit
    // 1 = Interrupt is enabled for this channel
    // 0 = Interrupt is disabled for this channel
    USBDMA1Cbits.DMAIE = 1;
    
    IEC4bits.USBDMAIE = 1; // Enable USB DMA interrupt.
}