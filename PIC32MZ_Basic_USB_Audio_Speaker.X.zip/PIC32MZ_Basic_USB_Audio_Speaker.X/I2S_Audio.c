/*
 * File name: I2S_Audio.c for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only a test example, it is a very stripped down version
 * from some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#include <xc.h>
#include <sys/attribs.h>
#include <sys/kmem.h>
#include "main.h"
#include "I2S_Audio.h"
#include "RefClock.h"
#include "usb.h"

void initI2S2(uint8_t clockSourceI2S2){
    // Initialize the SPI-2 module for Master Mode I2S Audio.
    SPI2CONbits.ON = 0;     // Stop SPI-2/I2S-2.
    SPI2STAT = 0;           // Clear SPI-1 status bits.
    SPI2CONbits.MSTEN = 1;  // Enable master mode.
    SPI2CONbits.SIDL = 0;   // 0 = Continue operation in Idle mode.
    
    //Enable Audio CODEC Support bit(1)
    // 1 = Audio protocol is enabled
    // 0 = Audio protocol is disabled
    SPI2CON2bits.AUDEN = 1;
    
    //Transmit Audio Data Format bit(1,2)
    // 1 = Audio data is mono (Each data word is transmitted on both left and 
    // right channels) 
    // 0 = Audio data is stereo
    SPI2CON2bits.AUDMONO = 0;
    
    // Audio Protocol Mode bit(1,2)
    // 11 = PCM/DSP mode
    // 10 = Right Justified mode 
    // 01 = Left Justified mode 
    // 00 = I2S mode
    SPI2CON2bits.AUDMOD = 0x0;
    
    // Per datasheet DS60001320E:
    //Note  1: This bit can only be written when the ON bit = 0.
    //      2: This bit is only valid for AUDEN = 1.
    
    //**************************************************************************
    
    // When AUDEN = 1:
    // MODE32   MODE16  Communication
    // 1        1       24-bit Data, 32-bit FIFO, 32-bit Channel/64-bit Frame
    // 1        0       32-bit Data, 32-bit FIFO, 32-bit Channel/64-bit Frame 
    // 0        1       16-bit Data, 16-bit FIFO, 32-bit Channel/64-bit Frame 
    // 0        0       16-bit Data, 16-bit FIFO, 16-bit Channel/32-bit Frame
    SPI2CONbits.MODE32 = 1;                 
    SPI2CONbits.MODE16 = 1;                 
    
    // Framed SPI Support bit
    // 1 = Framed SPI support is enabled (SSx pin used as FSYNC input/output)
    // 0 = Framed SPI support is disabled
    SPI2CONbits.FRMEN = 1;
    
    // Frame Sync Pulse Direction Control on SSx pin bit (Framed SPI mode only) 
    // 1 = Frame sync pulse input (Slave mode)
    // 0 = Frame sync pulse output (Master mode)
    SPI2CONbits.FRMSYNC = 0;
    
    // Frame Sync / Slave Select Polarity bit (Framed SPI or Master Transmit modes only) 
    // 1 = Frame pulse or SSx pin is active-high
    // 0 = Frame pulse or SSx is active-low
    SPI2CONbits.FRMPOL = 1;
    
    // Frame Sync Pulse Edge Select bit (Framed SPI mode only) 
    // 1 = Frame synchronization pulse coincides with the first bit clock
    // 0 = Frame synchronization pulse precedes the first bit clock
    SPI2CONbits.SPIFE = 1; // <-- Need to verify
    
    // This bit is not used in the Framed SPI mode. The user should program this 
    // bit to '0' for the Framed SPI mode (FRMEN = 1).
    // SPI Clock Edge Select bit(2)
    // 1 = Serial output data changes on transition from active clock state to Idle 
    // clock state (see CKP bit) 
    // 0 = Serial output data changes on transition from Idle clock state to 
    // active clock state (see CKP bit)
    SPI2CONbits.CKE = 0;
    
    // Master Clock Enable bit(1)
    // 1 = REFCLKO1 is used by the Baud Rate Generator
    // 0 = PBCLK2 is used by the Baud Rate Generator
    SPI2CONbits.MCLKSEL = clockSourceI2S2;    
                                            
    // Calculate the I2S audio BAUD rate corresponding to the audio sample rate.
    //SPI2BRG = (FPb2 / SampleRateI2S);       
    
    // Master Mode Slave Select Enable bit
    // 1 = Slave select SPI support is enabled. The SS pin is automatically 
    // driven during transmission in Master mode. Polarity is determined by 
    // the FRMPOL bit.
    // 0 = Slave select SPI support is disabled.
    SPI2CONbits.MSSEN = 1; 
    
    // Frame Sync Pulse Width bit
    // 1 = Frame sync pulse is one character wide
    // 0 = Frame sync is one clock wide
    SPI2CONbits.FRMSYPW = 1; // <-- Need to verify 
    
    // Frame Sync Pulse Counter bits. Controls the number of data characters 
    // transmitted per pulse. This bit is only valid in Framed mode.
    // 111 = Reserved 
    // 110 = Reserved 
    // 101 = Generate a frame sync pulse on every 32 data characters
    // 100 = Generate a frame sync pulse on every 16 data characters
    // 011 = Generate a frame sync pulse on every 8 data characters
    // 010 = Generate a frame sync pulse on every 4 data characters
    // 001 = Generate a frame sync pulse on every 2 data characters
    // 000 = Generate a frame sync pulse on every data character
    SPI2CONbits.FRMCNT = 0x5; // 32 data characters <-- Need to verify
    
    // Clock Polarity Select bit(3)
    // 1 = Idle state for clock is a high level; active state is a low level
    // 0 = Idle state for clock is a low level; active state is a high level
    SPI2CONbits.CKP = 0; // Idle state for clock is a low level
    
    // SPI Data Input Sample Phase bit
    //
    // Master mode (MSTEN = 1):
    // 1 = Input data sampled at end of data output time
    // 0 = Input data sampled at middle of data output time
    //
    // Slave mode (MSTEN = 0):
    // SMP value is ignored when SPI is used in Slave mode. The module always uses SMP = 0.
    //
    SPI2CONbits.SMP = 0;
    
    // DISSDI: Disable SDI bit(4)
    // 1 = SDI pin is not used by the SPI module (pin is controlled by PORT function) 
    // 0 = SDI pin is controlled by the SPI module
    SPI2CONbits.DISSDI = 0;
    
    // SPI Transmit Buffer Empty Interrupt Mode bits
    // 11 = Interrupt is generated when the buffer is not full (has one or more empty elements).
    // 10 = Interrupt is generated when the buffer is empty by one-half or more.
    // 01 = Interrupt is generated when the buffer is completely empty.
    // 00 = Interrupt is generated when the last transfer is shifted out of SPISR and transmit 
    // operations are complete.
    SPI2CONbits.STXISEL = 0x1;
    
    // SPI Receive Buffer Full Interrupt Mode bits
    // 11 = Interrupt is generated when the buffer is full.
    // 10 = Interrupt is generated when the buffer is full by one-half or more.
    // 01 = Interrupt is generated when the buffer is not empty.
    // 00 = Interrupt is generated when the last word in the receive buffer is 
    // read (i.e., buffer is empty).
    SPI2CONbits.SRXISEL = 0x3;
    
    // Per datasheet DS60001320E:
    // Note 1: This bit can only be written when the ON bit = 0. Refer to 
    //          Section 37.0 ?Electrical Characteristics? for maximum clock 
    //          frequency requirements.
    //
    //      2: This bit is not used in the Framed SPI mode. The user should 
    //          program this bit to ?0? for the Framed SPI mode (FRMEN = 1).
    //
    //      3: When AUDEN = 1, the SPI/I2S module functions as if the CKP bit is 
    //          equal to ?1?, regardless of the actual value of the CKP bit.
    //
    
    //**************************************************************************
    
    // Sign Extend Read Data from the RX FIFO bit (R/W)
    // 1 = Data from RX FIFO is sign extended
    // 0 = Data from RX FIFO is not sign extended
    SPI2CON2bits.SPISGNEXT = 0;
    
    // Enable Interrupt Events via FRMERR bit
    // 1 = Frame Error overflow generates error events 
    // 0 = Frame Error does not generate error events
    SPI2CON2bits.FRMERREN = 0;
    
    // Enable Interrupt Events via SPIROV bit 
    // 1 = Receive overflow generates error events
    // 0 = Receive overflow does not generate error events
    SPI2CON2bits.SPIROVEN = 0;
            
    // Enable Interrupt Events via SPITUR bit 
    // 1 = Transmit Underrun Generates Error Events
    // 0 = Transmit Underrun Does Not Generates Error Events
    SPI2CON2bits.SPITUREN = 0;
            
    // Ignore Receive Overflow bit (for Audio Data Transmissions)
    // 1 = A ROV is not a critical error; during ROV data in the FIFO is not 
    // overwritten by receive data 
    // 0 = A ROV is a critical error which stop SPI operation
    SPI2CON2bits.IGNROV = 1;
            
    // Ignore Transmit Underrun bit (for Audio Data Transmissions)
    // 1 = A TUR is not a critical error and zeros are transmitted until the 
    // SPIxTXB is not empty 
    // 0 = A TUR is a critical error which stop SPI operation
    SPI2CON2bits.IGNTUR = 1;
            
    /********************** End of SPI/I2S configuration **********************/
    
    // Initialize the reference clock to generate the bit rate for the audio samples.
    refClk1(sampleRate1);
    
    // Enable the I2S interface (SPI-2 module).
    //SPI2CONbits.ON = 1; // Now enabled/disabled in USB case 0x010B Set Interface.
}
