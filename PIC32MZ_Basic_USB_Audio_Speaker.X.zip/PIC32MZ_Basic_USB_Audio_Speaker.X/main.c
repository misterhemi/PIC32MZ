/*
 * File name: main.c for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

// Setup for PIC32MZ EF device for 200 MHz operation - Device Configuration Bits.
/*** DEVCFG0 ***/
#pragma config DEBUG =      OFF
#pragma config JTAGEN =     OFF
#pragma config ICESEL =     ICS_PGx1
#pragma config TRCEN =      OFF
#pragma config BOOTISA =    MIPS32
#pragma config FECCCON =    OFF_UNLOCKED
#pragma config FSLEEP =     OFF
#pragma config DBGPER =     PG_ALL
#pragma config SMCLR =      MCLR_NORM
#pragma config SOSCGAIN =   GAIN_LEVEL_3
#pragma config SOSCBOOST =  ON
#pragma config POSCGAIN =   GAIN_LEVEL_3
#pragma config POSCBOOST =  ON
#pragma config EJTAGBEN =   NORMAL
#pragma config CP =         OFF

/*** DEVCFG1 ***/
#pragma config FNOSC =      SPLL
#pragma config DMTINTV =    WIN_127_128
#pragma config FSOSCEN =    ON
#pragma config IESO =       ON
#pragma config POSCMOD =    EC
#pragma config OSCIOFNC =   ON
#pragma config FCKSM =      CSECME
#pragma config WDTPS =      PS1048576
#pragma config WDTSPGM =    STOP
#pragma config FWDTEN =     OFF
#pragma config WINDIS =     NORMAL
#pragma config FWDTWINSZ =  WINSZ_25
#pragma config DMTCNT =     DMT31
#pragma config FDMTEN =     OFF

/*** DEVCFG2 ***/
#pragma config FPLLIDIV =   DIV_3
#pragma config FPLLRNG =    RANGE_5_10_MHZ
#pragma config FPLLICLK =   PLL_POSC
#pragma config FPLLMULT =   MUL_50
#pragma config FPLLODIV =   DIV_2
#pragma config UPLLFSEL =   FREQ_24MHZ

/*** DEVCFG3 ***/
#pragma config USERID =     0xFFFF
#pragma config FMIIEN =     ON
#pragma config FETHIO =     ON
#pragma config PGL1WAY =    OFF
#pragma config PMDL1WAY =   ON
#pragma config IOL1WAY =    ON
#pragma config FUSBIDIO =   ON

/*** BF1SEQ0 ***/
#pragma config TSEQ =       0x0000
#pragma config CSEQ =       0xFFFF

#include <xc.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/attribs.h>
#include <sys/kmem.h>
#include "main.h"
#include "delay.h"
#include "usb.h"
#include "InterruptMask.h"


void main(){
    /********* System Initializations *********/
    initBoard();
    initDMA();
    initUSB();
    initUSBDMA();
    initI2S2(0);
    setAudioLevels();
    enableUSB = TRUE;
    /*************** End of Initializations ***************/
    
    DelayMs(500);
    
    /* Main Loop */
    while(1){
        
        /* Check if USB is connected/disconnected by monitoring VBUS */
        if(USBOTGbits.VBUS == VBUS_VALID && enableUSB == TRUE){
            connectUSB();
            enableUSB = FALSE;
        } else if(USBOTGbits.VBUS != VBUS_VALID && enableUSB == FALSE){
            disableUSB();
            enableUSB = TRUE;
        }
    }
}

void initBoard(){
    ANSELA = 0x00000000;    // Disable analog functions on Port A (digital only).
    ANSELB = 0x7FFFFFD0;    // Disable analog functions on B0, B1, B2, B3, B5 and B15
    ANSELC = 0x00000000;    // Disable analog functions on Port C (digital only).
    ANSELD = 0x00000000;    // Disable analog functions on Port D (digital only).
    ANSELE = 0x00000000;    // Disable analog functions on Port E (digital only).
    ANSELF = 0x00000000;    // Disable analog functions on Port F (digital only).
    ANSELG = 0x00000000;    // Disable analog functions on Port G (digital only).

    // You will need to edit these values for your specific design, however
    // note that port F3 is the USBID (on both 100 and 144 pin devices) which
    // determines if it's type A or type B USB. I have used one of the built-in
    // pull-up resistors (see below, in Enable pull-up resistor) to set this to
    // type B. Pulling it down would set it to type A.
    TRISA = 0x0000; // Set all port A bits as outputs
    TRISB = 0x000C; // Set all port B bits as outputs except B2, B3
    TRISC = 0x0008; // Set all port C bits as outputs except C3 
    TRISD = 0x4200; // Set all port D bits as outputs except D14 (SDI1/DO) and D9.
    TRISE = 0x0206; // Set all port E bits as outputs except E1, E2, E9
    TRISF = 0x0128; // Set all port F bits as outputs except F3 (USBID), F5, and F8 
    TRISG = 0x1001; // Set port G0 and G12 as an inputs. 
    
    /* Configure SPI2 ports (for I2S audio Interface) */
    SDI2Rbits.SDI2R = 0xC;      // Set RPG0 as SDI2.
    RPG7Rbits.RPG7R = 0x6;      // Set RPG7 as SDO2.
    RPD5Rbits.RPD5R = 0x6;      // Set RPD5 as SS2/Fsync.
    
    /* Set Open Drain outputs for I2C busses. */
    ODCAbits.ODCA14 = 1;        // Enable Open Drain on Port A14 for SCL1
    ODCAbits.ODCA15 = 1;        // Enable Open Drain on Port A15 for SDA1
    ODCAbits.ODCA2 = 1;         // Enable Open Drain on Port A2 for SCL2
    ODCAbits.ODCA3 = 1;         // Enable Open Drain on Port A3 for SDA2
    
    /* Enable pull-up resistor on MISO/DO on SPI-1 and USBID */
    CNPUDbits.CNPUD14 = 1;  // Pull-up enabled on RPD14 (so SDI1 isn't floating).
    CNPUGbits.CNPUG0 = 1;   // Pull-up enabled on RPG0 (so SDI2 isn't floating).
    CNPUFbits.CNPUF3 = 1;   // Pull-up enables on RPF3 (To set USB as a B-Device )
    
    /* Configure PBCLK2 which is used by the UART and SPI Baud Rate Generators (BRG) */
    PB2DIVbits.ON = 0;          // Disable PBCLK2
    T2CONbits.TCS = 0;          // Use system clock for PBCLK2 for clock source.
    PB2DIVbits.PBDIV = 0x04;    // Set the divisor for PBCLK2 (SYSCLK / 5).
    PB2DIVbits.ON = 1;          // Enable PBCLK2
    
    /* Configure interrupts */
    PRISS = 0x76543210ul; /* assign shadow set #7-#1 to priority level #7-#1 ISRs */
    
    /* Enable interrupts */
    IEC4bits.DMA0IE = 1;    //  Enable DMA0 Interrupts
    IEC4bits.DMA1IE = 1;    //  Enable DMA1 Interrupts
    
    IEC4bits.SPI2RXIE = 1;
    IEC4bits.SPI2TXIE = 1;
  
    INTCONbits.MVEC = 1;    // Enable system wide multi-vectored interrupts.
    __builtin_enable_interrupts();
    
    // Ensure LEDs 4a,b,c are off (high) because they're active low devices.
    led_4b = 1;
    led_4g = 1;
    led_4r = 1;
    
    return;
}

void setAudioLevels(){
    // You may want to edit these values. They are simply default value
    // and dependent upon the resolution you choose.
    minMasterOut_featUnit2[0] = 0x00; 
    minMasterOut_featUnit2[1] = 0x00;
    
    minChannel1Out_featUnit2[0] = 0x00; 
    minChannel1Out_featUnit2[1] = 0x00;
    
    minChannel2Out_featUnit2[0] = 0x00; 
    minChannel2Out_featUnit2[1] = 0x00;

    maxMasterOut_featUnit2[0] = 0x00; 
    maxMasterOut_featUnit2[1] = 0x63;
    
    maxChannel1Out_featUnit2[0] = 0x00; 
    maxChannel1Out_featUnit2[1] = 0x63;
    
    maxChannel2Out_featUnit2[0] = 0x00; 
    maxChannel2Out_featUnit2[1] = 0x63;

    resolutionMasterOut_featUnit2[0] = 0x1B; 
    resolutionMasterOut_featUnit2[1] = 0x01;
    
    resolutionChannel1Out_featUnit2[0] = 0x1B; 
    resolutionChannel1Out_featUnit2[1] - 0x01;
    
    resolutionChannel2Out_featUnit2[0] = 0x1B;
    resolutionChannel2Out_featUnit2[1] = 0x01;
    
}
