/*
 * File name: USB_Descriptors.h for PIC32MZ Basic USB Audio Speaker example
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * As of 18 January 2020 I have been unable to get the USB DMA to function.
 * NOTE: The PIC32MZ USB has it's own USB DMA in addition to the general
 *       purpose DMA.
 * My eventual goal is to get the USB DMA to function, transfer the audio 
 * data to a buffer, then use the general purpose DMA to transfer the
 * data from the buffer to the I2S/SPI port.
 * 
 * *****************************************************************************
 * WARNING!!!!!:
 * If you choose to edit this file I suggest making a backup copy of it first.
 * If the USB Device and/or Configuration descriptors aren't correct the USB
 * device MAY fail to enumerate
 * *****************************************************************************
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#ifndef _USB_DESCRIPTORS_H    /* Guard against multiple inclusion */
#define _USB_DESCRIPTORS_H

/*********************************************************************
 Device Descriptors
 *********************************************************************/
unsigned char Dev_desc[] = {
/* Descriptor Length						*/ 0x12, 
/* DescriptorType: DEVICE					*/ 0x01,
/* bcdUSB (ver 2.0)							*/ 0x00,0x02,
/* bDeviceClass								*/ 0x00,
/* bDeviceSubClass							*/ 0x00,
/* bDeviceProtocol							*/ 0x00,
/* bMaxPacketSize0							*/ 0x40, 
/* idVendor									*/ 0xD8,0x04, /* e.g. - 0x1234 */
/* idProduct								*/ 0x01,0x00, /* e.g. - 0x0001 */
/* bcdDevice								*/ 0x00,0x01, /* e.g. - 01.00 */
/* iManufacturer							*/ 0x01,
/* iProduct									*/ 0x02,
/* iSerialNumber							*/ 0x03,
/* bNumConfigurations						*/ 0x01
};

unsigned char DeviceQualifierDesc[] = {
/*********************************************************************
 Device Qualifier Descriptor for USB 2.0
 *********************************************************************/
/* bLength                                  */ 0x0A,
/* bDescriptorType: DEVICE_QUALIFIER        */ 0x06,
/* bcdUSB                                   */ 0x00,0x02,
/* bDeviceClass                             */ 0xEF, 
/* bDeviceSubClass                          */ 0x02,
/* bDeviceProtocol                          */ 0x01,
/* bMaxPacketSize                           */ 0x40, /* May need to verify - 64 bytes */
/* bNumConfigurations                       */ 0x01,
/* bReserved (must be zero)                 */ 0x00                                               
};

/*
 *
 *
 * Summary description:
 * This file contains the USB descriptors for the USB speaker.
 * 
 * As this is a preliminary version and is subject to change and
 * there are a few changes that will be required before being used in
 * a release version. They are as follows:
 * 	1. The USB VID (idVendor) needs to be changed upon acquiring one from
 *		the USB-IF for your company/corporation/business, etc.
 *
 *	2. idProduct, bcdDevice would also need to be updated in addition to 
 *		any serial numbers. Some of those are contained in the device 
 *      descriptor.
 * 
 *	3. When adding features such as Mixer Units, etc also update the 
 *		wTotalLength values in the Configuration Descriptors section
 *		and in the Class Specific AC Interface Header (if necessary).
 *
 *	The Endpoints are as follows:
 *		Endpoint	Type			Direction	Description		Packet Size
 *			1		Isochronous		OUT			Audio           512 bytes
 *          2		Isochronous		IN          Sync            8 bytes
 *
 * 
 */		
unsigned char DescriptorArray[] = {
/*********************************************************************
 Configuration Descriptors
 *********************************************************************/
/*  bLength (Descriptor Length)             */ 0x09,
/*  bDescriptorType: CONFIG					*/ 0x02,
/*  wTotalLength							*/ 0x7F,0x00,/* 0x78, 0x00 */
/*  bNumInterfaces							*/ 0x02,
/*  bConfigurationValue						*/ 0x01,
/*  iConfiguration							*/ 0x00,
/*  bmAttributes							*/ 0x80,
/*  bMaxPower								*/ 0x64, /* Value x 2mA, set to 0 for self powered, was 0x32 */
/*********************************************************************
 Standard AC (Audio Class) Interface Descriptor - Interface 0
 *********************************************************************/                                               
/* bLength                                  */ 0x09,
/* bDescriptorType: INTERFACE               */ 0x04,
/* bInterfaceNumber                         */ 0x00,
/* bAlternateSetting                        */ 0x00,
/* bNumEndpoints: 0 endpoint(s)             */ 0x00,
/* bInterfaceClass: AUDIO                   */ 0x01,
/* bInterfaceSubclass: AUDIO_CONTROL        */ 0x01,
/* bInterfaceProtocol                       */ 0x00,
/* iInterface                               */ 0x00,
/*********************************************************************
 Class-specific AC (Audio Class) Interface Header Descriptor
 *********************************************************************/                                               
/* bLength                                  */ 0x09,
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: HEADER               */ 0x01,
/* bcdADC                                   */ 0x00,0x01,/* 0x00,0x01 */
/* wTotalLength: This + IN term + OUT term  */ 0x2B,0x00,/* was 0x4E, 0x00 */
/* bInCollection:Num of streaming intrfaces */ 0x01, 
/* baInterfaceNr(1)                         */ 0x01,
/*********************************************************************
 Input Terminal Descriptor (ID = 1)
 *********************************************************************/                                               
/* bLength                                  */ 0x0C,/*0x0C*/
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: INPUT_TERMINAL       */ 0x02,
/* bTerminalID                              */ 0x01,
/* wTerminalType: USB Streaming             */ 0x01,0x01,
/* bAssocTerminal                           */ 0x00,
/* bNrChannels                              */ 0x02,
/* wChannelConfig                           */ 0x03,0x00,
/* iChannelNames                            */ 0x00,
/* iTerminal                                */ 0x00,
/*********************************************************************
 Feature Unit (ID = 2)
 *********************************************************************/
/* bLength                                  */ 0x0D, 
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: FEATURE_UNIT         */ 0x06,
/* bUnitID                                  */ 0x02,
/* bSourceID: Input Terminal 1              */ 0x01,
/* bControlSize                             */ 0x02, 
/* bmaControls(0): Master Channel           */ 0x03,0x00,
/* bmaControls(1): Left Channel             */ 0x03,0x00,
/* bmaControls(2): Right Channel            */ 0x03,0x00,
/* iFeature                                 */ 0x00,                                               
/*********************************************************************
 Output Terminal Descriptor (ID = 3)
 *********************************************************************/                                               
/* bLength                                  */ 0x09,
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: OUTPUT_TERMINAL      */ 0x03,
/* bTerminalID                              */ 0x03,
/* wTerminalType: Speaker                   */ 0x01,0x03,
/* bAssocTerminal                           */ 0x00,
/* bSourceID: Feature Unit 2                */ 0x02,
/* iFeature                                 */ 0x00,
/*********************************************************************
 Standard AS (Audio Streaming) Interface 1 Descriptor - Alt. Setting 0
 *********************************************************************/                                               
/* bLength                                  */ 0x09,
/* bDescriptorType: INTERFACE               */ 0x04,
/* bInterfaceNumber                         */ 0x01,
/* bAlternateSetting                        */ 0x00,
/* bNumEndpoints: 0 endpoint(s)             */ 0x00,
/* bInterfaceClass: AUDIO                   */ 0x01,
/* bInterfaceSubclass: AUDIO_STREAMING      */ 0x02,
/* bInterfaceProtocol                       */ 0x00,
/* iInterface                               */ 0x06, 
/*********************************************************************
 Standard AS (Audio Streaming) Interface 1 Descriptor - Alt. Setting 1
 *********************************************************************/                                               
/* bLength                                  */ 0x09,
/* bDescriptorType: INTERFACE               */ 0x04,
/* bInterfaceNumber                         */ 0x01,
/* bAlternateSetting                        */ 0x01,
/* bNumEndpoints: 1 endpoint(s)             */ 0x01,
/* bInterfaceClass: AUDIO                   */ 0x01,
/* bInterfaceSubclass: AUDIO_STREAMING      */ 0x02,
/* bInterfaceProtocol                       */ 0x00,
/* iInterface                               */ 0x00,
/*********************************************************************
 Class-specific AS (Audio Streaming) General Interface Descriptor
 *********************************************************************/
/* bLength                                  */ 0x07,
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: MS_HEADER subtype.   */ 0x01,
/* bTerminalLink: Input Terminal (ID = 1)   */ 0x01,
/* bDelay                                   */ 0x01,
/* wFormatTag: PCM Format                   */ 0x01,0x00,
/*********************************************************************
 Type I Format Type Descriptor
 *********************************************************************/                                               
/* bLength                                  */ 0x14,
/* bDescriptorType: CS_INTERFACE            */ 0x24,
/* bDescriptorSubtype: FORMAT_TYPE          */ 0x02,
/* bFormatType: FORMAT_TYPE_I.              */ 0x01,
/* bNrChannels: Two channels                */ 0x02,
/* bSubFrameSize: Four bytes per sub-frame  */ 0x04,
/* bBitResolution: 24 bits per sample.      */ 0x18,
/* bSamFreqType: Four frequencies supported */ 0x04,
/* tSamFreq(1) 0x017700 = 96000 Hz          */ 0x00,0x77,0x01,
/* tSamFreq(2) 0x015888 = 88200 Hz          */ 0x88,0x58,0x01, 
/* tSamFreq(3) 0x00BB80 = 48000 Hz			*/ 0x80,0xBB,0x00,
/* tSamFreq(4) 0x00AC44 = 44100 Hz          */ 0x44,0xAC,0x00,
/*********************************************************************
 Standard Endpoint Descriptor OUT
 *********************************************************************/                                               
/* bLength                                  */ 0x07,
/* bDescriptorType: ENDPOINT                */ 0x05,
/* bEndpointAddress: OUT Endpoint 1         */ 0x01, 
/* bmAttributes: Isochronous Async (0x05)   */ 0x05, /* 0x01 = Isochronous + 0x04 = Async or 0x08 = Adaptive or 0x0C = Sync */
/* wMaxPacketSize: 512 bytes                */ 0x00,0x02,
/* wInterval:                               */ 0x01,
/*********************************************************************
 Class-specific Isochronous Audio Data Endpoint Descriptor
 *********************************************************************/
/* bLength                                  */ 0x07,
/* bDescriptorType: CS_ENDPOINT             */ 0x25,
/* bDescriptorSubtype: GENERAL              */ 0x01,
/* bmAttributes                             */ 0x01, /* Sampling frequency control, no pitch control, no packet padding. */
/* bLockDelayUnits                          */ 0x00,
/* wLockDelay                               */ 0x00,0x00,
/*********************************************************************
 Standard AS Isochronous Feedback Endpoint Descriptor
 *********************************************************************/
/* bLength                                  */ 0x07,
/* bDescriptorType: ENDPOINT             	*/ 0x05,
/* bEndpointAddress: IN Endpoint 2          */ 0x82,
/* bmAttributes (0x11)                      */ 0x11, /* Isochronous, No Sync., Feedback */
/* wMaxPacketSize                          	*/ 0x04,0x00, /* 0x03, 0x00 = 3 bytes 10.14 format or 0x04, 0x00 = 4 bytes 16.16 format */
/* bInterval                               	*/ 0x01
};

/*********************************************************************
 String Descriptor Table (below) - These must be Unicode 16 (UTF-16)
 *********************************************************************/

/*********************************************************************
Language ID Descriptor
*********************************************************************/
unsigned char string0[] = {	
/* 	Descriptor Length                       */	4, /* 4 or 0x04 */
/*  DescriptorType: STRING  				*/	0x03,
/* 	Language ID: English					*/	0x09,0x04
												}; // 0x0409
/********************************************************************
String Descriptor: "Your Company Name"
*********************************************************************/
unsigned char string1[] = {	
/* 	Descriptor Length                       */	36,
/*  DescriptorType: STRING  				*/  0x03,
/*	Vendor Name     						*/	'Y',0,'o',0,'u',0,'r',0,' ',0,
'C',0,'o',0,'m',0,'p',0,'a',0,'n',0,'y',0,' ',0,'N',0,'a',0,'m',0,'e',0	
};
/*********************************************************************
 String Descriptor (Product Name): "USB Speaker Example"
 *********************************************************************/
unsigned char string2[] = {
/* Descriptor Length                        */ 	40,
/* DescriptorType: STRING                   */  0x03,
/* Product Name                             */	'U',0,'S',0,'B',0,' ',0,
'S',0,'p',0,'e',0,'a',0,'k',0,'e',0,'r',0,' ',0,'E',0,'x',0,'a',0,'m',0,
'p',0,'l',0,'e',0
 }; 
/*********************************************************************
 String Descriptor (Serial Number): "123-4567"
 *********************************************************************/
unsigned char string3[] = {
/* Descriptor Length                        */ 	18, /* 18 or 0x12 */
/* DescriptorType: STRING                   */  0x03,
/* Serial Number                            */	'1',0,'2',0,'3',0,'-',0,
'4',0,'5',0,'6',0,'7',0
};	// 123-4567

unsigned char string4[] = {
/* Descriptor Length                        */ 	4,
/*  DescriptorType: STRING  				*/  0x03,
/* Configuration                            */	0x01, 0x00
};

/*********************************************************************
 String Descriptor (Interface): "PIC32MZ Input"
 *********************************************************************/
unsigned char string5[] = {
/* Descriptor Length                        */ 	28, 
/*  DescriptorType: STRING  				*/  0x03,
/* Interface                                */	'P',0,'I',0,'C',0,'3',0,'2',0,'M',0,'Z',0,' ',0,
'I',0,'n',0,'p',0,'u',0,'t',0
};

/*********************************************************************
 String Descriptor (Interface): "PIC32MZ Output"
 *********************************************************************/
unsigned char string6[] = {
/* Descriptor Length                        */ 	30,
/*  DescriptorType: STRING  				*/  0x03,
/* Interface                                */	'P',0,'I',0,'C',0,'3',0,'2',0,'M',0,'Z',0,' ',0,
'O',0,'u',0,'t',0,'p',0,'u',0,'t',0
};

/*********************************************************************
 String Descriptor 7
 *********************************************************************/
unsigned char string7[] = {
/* Descriptor Length                        */ 	16,
/*  DescriptorType: STRING  				*/  0x03,
/*                                          */	'S',0,'t',0,'r',0,'i',0,'n',0,'g',0,'7',0
};

/*********************************************************************
 String Descriptor 8
 *********************************************************************/
unsigned char string8[] = {
/* Descriptor Length                        */ 	16,
/*  DescriptorType: STRING  				*/  0x03,
/*                                          */	'S',0,'t',0,'r',0,'i',0,'n',0,'g',0,'8',0
};

/*********************************************************************
 String Descriptor 9
 *********************************************************************/
unsigned char string9[] = {
/* Descriptor Length                        */ 	16,
/*  DescriptorType: STRING  				*/  0x03,
/*                                          */	'S',0,'t',0,'r',0,'i',0,'n',0,'g',0,'9',0
};

#endif /* _USB_DESCRIPTORS_H */

/* *****************************************************************************
 End of File
 */
