
#include "main.h"
#include "delay.h"

// Generic delay function
void DelayUs(uint32_t usec)
{
	unsigned int tWait, tStart;
    
    tWait = (GetSystemClock()/2000000) * usec;
    tStart =_mfc0(9,0);
    while((_mfc0(9,0) - tStart) < tWait);		// wait for the time to pass 
}
