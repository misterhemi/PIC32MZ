/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    delay.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _DELAY_H    /* Guard against multiple inclusion */
#define _DELAY_H

#include <xc.h>

void DelayUs(uint32_t usec);

#define DelayMs(x) DelayUs(x * 1000)
#define delay_us(x) DelayUs(x)

#define Delay1() DelayUs(50) // 100
#define Delay0() DelayUs(25) // 50
#define Delay3() DelayUs(1500) // 3000
#define Delay4() DelayUs(2050) // 4100
#define Delay40() DelayUs(20000) // 40000

#endif /* _DELAY_H */

/* *****************************************************************************
 End of File
 */
