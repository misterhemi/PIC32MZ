/*
 * File name: USB.c for PIC32MZ Basic USB Audio Speaker example
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * As of 11 January 2020 I have been unable to get the USB DMA to function.
 * NOTE: The PIC32MZ USB has it's own USB DMA in addition to the general
 *       purpose DMA.
 * My eventual goal is to get the USB DMA to function, transfer the audio 
 * data to a buffer, then use the general purpose DMA to transfer the
 * data from the buffer to the I2S/SPI port.
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#include <xc.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/attribs.h>
#include <sys/kmem.h>
#include "main.h"
#include "dma.h"
#include "I2S_Audio.h"
#include "usb.h"
#include "USB_Descriptors.h"
#include "usb_dma.h"
#include "InterruptMask.h"

uint8_t doubleZero[] = {0x00, 0x00}; // Double Zero
uint8_t __attribute__((coherent)) __attribute__((aligned(32))) USB_EP1_buffer[(EP1RXBUFFSIZE * 8)];

void __attribute__((interrupt(ipl4srs), at_vector(_USB_VECTOR), no_fpu, nomips16)) USB_Handler(void){
    
    if(USBCSR2bits.RESETIF){ // In Device mode, indicates reset signaling is detected on the bus.
        USBCSR0bits.HSEN = 1;       // 1 = Enable High Speed (480Mbps) USB mode.
    
        // Clear the interrupt flags
        IFS4CLR = _IFS4_USB_GENERAL_EVENT_MASK;      
        USBCSR0bits.EP0IF = 0;
        USBCSR1bits.EP1RXIF = 0;
        USBCSR0bits.EP2TXIF = 0;
        USBCSR2bits.SOFIF = 0;
    
    
        // MODE: Endpoint Direction Control bit
        // 1 = Endpoint is TX
        // 0 = Endpoint is RX    
        USBE1CSR0bits.MODE = 0;     // 0 = Endpoint is RX.
        USBE2CSR0bits.MODE = 1;     // 1 = Endpoint is TX
    
        // Configure endpoint 0 first.
        USBE0CSR0bits.TXMAXP = EP0BUFFSIZE; // Set endpoint 0 buffer size (multiples of 8).
    
        // These are multiples of 8, e.g.- "1" is 8 bytes, "8" is 64 bytes 
        USBE1CSR1bits.RXMAXP = EP1RXBUFFSIZE;   // Endpoint 1 - Maximum RX Payload Per Transaction Control bits 
        USBE2CSR0bits.TXMAXP = EP2TXBUFFSIZE;   // Endpoint 2 - Maximum TX Payload per transaction Control bits
    
        USBE1CSR3bits.PROTOCOL = 1; // Endpoint 1 - RX Endpoint Protocol Control bits
        USBE2CSR2bits.PROTOCOL = 1; // Endpoint 2 - TX Endpoint Protocol Control bits
        //PROTOCOL<1:0>: RX/TX Endpoint Protocol Control bits 
        //11 = Interrupt
        //10 = Bulk
        //01 = Isochronous
        //00 = Control
    
        // ISOUPD: ISO Update bit (Device mode only; unimplemented in Host mode)
        // 1 = USB module will wait for a SOF token from the time TXPKTRDY is set 
        // before sending the packet. 
        // 0 = No change in behavior.
        USBCSR0bits.ISOUPD = 1; 
    
        // DYNFIFOS: Dynamic FIFO Sizing Option bit 
        // 1 = Dynamic FIFO sizing is supported
        // 0 = No Dynamic FIFO sizing is supported
        USBE0CSR3bits.DYNFIFOS = 1;
    
        // Datasheet DS60001320E-page 232
        // 1111 = Reserved
        // 1110 = Reserved 
        // 1101 = 8192 bytes 
        // 1100 = 4096 bytes 
        // 1011 = 2038 bytes 
        // 1010 = 1024 bytes
        // 1001 = 512 bytes 
        // 1000 = 256 bytes
        // 0111 = 128 bytes
        // 0110 = 64 bytes
        // 0101 = 32 bytes
        // 0100 = 16 bytes
        // 0011 = 8 bytes
        // 0010 = Reserved
        // 0001 = Reserved
        // 0000 = Reserved or endpoint has not been configured
        USBE1CSR3bits.RXFIFOSZ = 0xA;   // Receive FIFO Size bits - 1024 bytes
        USBE2CSR3bits.TXFIFOSZ = 0x3;   // Transmit FIFO Size bits - 8 bytes
    
        // Endpoint TX/RX Polling Interval/NAK Limit bits
        // For Interrupt and Isochronous transfers, this field defines the polling 
        // interval for the endpoint. For Bulk end-points, this field sets the 
        // number of frames/microframes after which the endpoint should time out on 
        // receiving a stream of NAK responses.
        //
        // Transfer Type    Speed           Valid Values(m) Interpretation
        // Isochronous      Full or High    0x01 to 0x10    Polling interval is 
        //                                                  2^(m-1) frames/microframes.
        USBE1CSR3bits.RXINTERV = 0x01; // Poll every microframe (8th of a frame)
        USBE2CSR2bits.TXINTERV = 0x04; // Poll every 8 microframes (once per frame)
    
        // MULT<4:0>: Multiplier Control bits
        // For Isochronous/Interrupt endpoints or of packet splitting on Bulk 
        // endpoints, multiplies RXMAXP/TXMAXP by MULT+1 for the payload size.
        // For Bulk endpoints, MULT can be up to 32 and defines the number of ?USB? 
        // packets of the specified payload into which a single data packet placed 
        // in the FIFO should be split, prior to transfer. The data packet is 
        // required to be an exact multiple of the payload specified by TXMAXP.
        // For Isochronous/Interrupts endpoints operating in Hi-Speed mode, MULT may 
        // be either 2 or 3 and specifies the maximum number of such transactions 
        // that can take place in a single microframe.
        USBE1CSR1bits.MULT = 3; // RX
    
        // NOTE: We don't set the TX speed in device mode, as noted below from the 
        // data sheet (DS60001320D-page 223):
        // TX Endpoint Operating Speed Control bits (Host mode)
        // In HOST mode it would use CSR2 to set the TX speed, for example:
        // USBExCSR2bits.SPEED = z; 
        // Where x is the endpoint number and z is the speed.
        // USBEnCSR2 for TX endpoint, USBEnCSR3 for RX endpoint
        USBE0CSR2bits.SPEED = 1;        // Endpoint 0 Operating Speed Control bits
        USBE1CSR3bits.SPEED = 1;        // Endpoint 1: RX Endpoint Operating Speed Control bits - High speed
     
        // ISO: Isochronous Endpoint Control bit (Device mode)
        // 1 = Enable the TX/RX endpoint for Isochronous transfers 
        // 0 = Enable the TX/RX endpoint for Bulk/Interrupt transfers
        // USBEnCSR0 for TX endpoint, USBEnCSR1 for RX endpoint
        USBE1CSR1bits.ISO = 1;      // Isochronous RX Endpoint Enable bit (Device mode).
        USBE2CSR0bits.ISO = 1;      // Isochronous TX Endpoint Enable bit (Device mode).
    
        /* Enable Endpoint interrupts */
        USBCSR1bits.EP0IE = 1;      // Endpoint 0 interrupt enable
        USBCSR2bits.EP1RXIE = 1;    // Endpoint 1 RX interrupt enable
        USBCSR1bits.EP2TXIE = 1;    // Endpoint 2 TX interrupt enable
    
        USBCSR2bits.RESETIF = 0;
    }
    
    /* Start of Frame (SOF)/MicroFrame - Audio Feedback Calculation */
    if(USBCSR2bits.SOFIF){
        
    USBCSR2bits.SOFIF = 0;  // Clear Start of Frame (SOF)/MicroFrame Interrupt.
    }
    
    /* Endpoint 0 Interrupt Handler */
    if(USBCSR0bits.EP0IF){
        
        if(setDevAddr == TRUE){ // Set Address, upon first IN transaction
            setAddress(usbAddress);
            setDevAddr = FALSE;
        }
        
        if(USBE0CSR0bits.RXRDY){
            ep0rbc = USBE0CSR2bits.RXCNT; // Endpoint 0 - Received Bytes Count
            tempData = (uint8_t *)&USBFIFO0;
               
                for(i = 0; i < ep0rbc; i++){
                    ep0data[i] = *(tempData + (i & 3));
                }
            USBE0CSR0bits.RXRDYC = 1;
               
            // The packet length of control transfers in low speed devices must be 
            // 8 bytes, high speed devices allow a packet size of 8, 16, 32 or 64 bytes 
            // and full speed devices must have a packet size of 64 bytes.
            bmbRequest = (ep0data[0] << 8) | ep0data[1]; // bmRequestType, bRequest
            wValue = (ep0data[3] << 8) | ep0data[2];
            wIndex = (ep0data[5] << 8) | ep0data[4];
            wLength = (ep0data[7] << 8) | ep0data[6];
            
            controlTrans();  // Process Control Transfers and Packets.
        }
        
        
        if(USBE0CSR0bits.SETEND){
                USBE0CSR0bits.SETENDC = 1;
        }
    
    USBCSR0bits.EP0IF = 0;  // Clear the USB EndPoint 0 Interrupt Flag.
    } 
    
    
    /* Endpoint 1 RX Interrupt Handler */
    if(USBE1CSR1bits.RXPKTRDY){ // ISOCHRONOUS Endpoint 3 Received A Packet.
        
            // Get the count of bytes to be transferred from Endpoint 3.
            // RXCNT<13:0>: Receive Count bits
            // The number of received data bytes in the RX FIFO endpoint. The 
            // value returned changes as the contents of the FIFO change and is 
            // only valid while RXPKTRDY is set.
            ep1rbc = USBE1CSR2bits.RXCNT;
            
            
    #ifdef useUSBDMA
            // Set the count of bytes to be transferred via USB DMA 2 to the 
            // EP3 buffer, and from the EP3 buffer to I2S-2 (SPI2).
            USBDMA2Nbits.DMACOUNT = ep1rbc;
            //DCH1CSIZbits.CHCSIZ = ep1rbc;
       
            // DMAEN: DMA Enable bit
            // 1 = Enable the DMA transfer and start the transfer 
            // 0 = Disable the DMA transfer
            USBDMA2Cbits.DMAEN = 1;
    #else            
        rxAudioISO_ep1(); // Alternate method.
    #endif

        USBE1CSR1bits.RXPKTRDY = 0;
        
        
    USBCSR1bits.EP1RXIF = 0;
    led_1 = ~led_1;
    }
    
    // NOTE: Bit 18 is shared by OVERRUN (device mode) and ERROR (host mode)
    //
    // OVERRUN: Data Overrun Status bit (Device mode)
    // 1 = An OUT packet cannot be loaded into the RX FIFO.
    // 0 = Written by software to clear this bit
    // This bit is only valid when the endpoint is operating in ISO mode. 
    // In Bulk mode, it always returns '0'.
    //
    // ERROR: No Data Packet Received Status bit (Host mode)
    // 1= Three attempts have been made to receive a packet and no data packet
    // has been received. An interrupt is generated.
    // 0 = Written by the software to clear this bit.
    // This bit is only valid when the RX endpoint is operating in Bulk or 
    // Interrupt mode. In ISO mode, it always returns '0'.
    if(USBE1CSR1bits.ERROR){
            USBE1CSR1bits.ERROR = 0; // Clear the OVERRUN (see above comments)
        }
    
    /* Endpoint 2 TX Interrupt Handler */
    if(USBCSR0bits.EP2TXIF){ // ISOCHRONOUS Endpoint 4 Transmit A Packet.
        
    USBCSR0bits.EP2TXIF = 0;        // Supposedly Cleared By Hardware (Clear Just In Case).
    } 
    
    IFS4CLR = _IFS4_USB_GENERAL_EVENT_MASK; // Reset the USB Interrupt flag.
}

void initUSB(){
    // Configure the USB hardware and registers.
    USBCSR0bits.SOFTCONN = 0;   // 1 = The USB D+/D- lines are enabled and active, 
                                // 0 = The USB D+/D- lines are disabled and are tri-stated.
    
    USBCSR0bits.HSEN = 1;       // 1 = Enable High Speed (480Mbps) USB mode.
    
    /* Disable Endpoint interrupts */
    USBCSR1bits.EP0IE = 0;      // Endpoint 0 interrupt disable
    USBCSR2bits.EP1RXIE = 0;    // Endpoint 1 RX interrupt disable
    USBCSR1bits.EP2TXIE = 0;    // Endpoint 2 TX interrupt disable
    
    USBCSR2bits.SOFIE = 0;      // Disable Start of Frame event interrupt.
    
    USBCSR2bits.RESETIE = 0; 
    
    USBCRCONbits.USBIE = 0;     // Disable general interrupt from USB module
    IEC4bits.USBIE = 0;         // Disable the USB interrupt.
    
    // Clear the interrupt flags
    IFS4CLR = _IFS4_USB_GENERAL_EVENT_MASK;      
    USBCSR0bits.EP0IF = 0;
    USBCSR1bits.EP1RXIF = 0;
    USBCSR0bits.EP2TXIF = 0;
    USBCSR2bits.SOFIF = 0;
    
    IPC33bits.USBIP = 4;        // USB Interrupt Priority.
    IPC33bits.USBIS = 3;        // USB Interrupt Sub-Priority.
    
    // MODE: Endpoint Direction Control bit
    // 1 = Endpoint is TX
    // 0 = Endpoint is RX    
    USBE1CSR0bits.MODE = 0;     // 0 = Endpoint is RX.
    USBE2CSR0bits.MODE = 1;     // 1 = Endpoint is TX
    
    // Configure endpoint 0 first.
    //USBE0CSR3bits.DYNFIFOS = 1; // Enable Dynamic FIFOs.
    USBE0CSR0bits.TXMAXP = EP0BUFFSIZE; // Set endpoint 0 buffer size (multiples of 8).
    
    // These are multiples of 8, e.g.- "1" is 8 bytes, "8" is 64 bytes 
    USBE1CSR1bits.RXMAXP = EP1RXBUFFSIZE;   // Endpoint 1 - Maximum RX Payload Per Transaction Control bits 
    USBE2CSR0bits.TXMAXP = EP2TXBUFFSIZE;   // Endpoint 2 - Maximum TX Payload per transaction Control bits
    
    USBE1CSR3bits.PROTOCOL = 1; // Endpoint 1 - RX Endpoint Protocol Control bits
    USBE2CSR2bits.PROTOCOL = 1; // Endpoint 2 - TX Endpoint Protocol Control bits
        //PROTOCOL<1:0>: RX/TX Endpoint Protocol Control bits 
        //11 = Interrupt
        //10 = Bulk
        //01 = Isochronous
        //00 = Control
    
    // ISOUPD: ISO Update bit (Device mode only; unimplemented in Host mode)
    // 1 = USB module will wait for a SOF token from the time TXPKTRDY is set 
    // before sending the packet. 
    // 0 = No change in behavior.
    USBCSR0bits.ISOUPD = 1; 
    
    // DYNFIFOS: Dynamic FIFO Sizing Option bit 
    // 1 = Dynamic FIFO sizing is supported
    // 0 = No Dynamic FIFO sizing is supported
    USBE0CSR3bits.DYNFIFOS = 1;
    
    // Datasheet DS60001320E-page 232
    // 1111 = Reserved
    // 1110 = Reserved 
    // 1101 = 8192 bytes 
    // 1100 = 4096 bytes 
    // 1011 = 2038 bytes 
    // 1010 = 1024 bytes
    // 1001 = 512 bytes 
    // 1000 = 256 bytes
    // 0111 = 128 bytes
    // 0110 = 64 bytes
    // 0101 = 32 bytes
    // 0100 = 16 bytes
    // 0011 = 8 bytes
    // 0010 = Reserved
    // 0001 = Reserved
    // 0000 = Reserved or endpoint has not been configured
    USBE1CSR3bits.RXFIFOSZ = 0xA;   // Receive FIFO Size bits - 1024 bytes
    USBE2CSR3bits.TXFIFOSZ = 0x3;   // Transmit FIFO Size bits - 8 bytes
    
    // Endpoint TX/RX Polling Interval/NAK Limit bits
    // For Interrupt and Isochronous transfers, this field defines the polling 
    // interval for the endpoint. For Bulk end-points, this field sets the 
    // number of frames/microframes after which the endpoint should time out on 
    // receiving a stream of NAK responses.
    //
    // Transfer Type    Speed           Valid Values(m) Interpretation
    // Isochronous      Full or High    0x01 to 0x10    Polling interval is 
    //                                                  2^(m-1) frames/microframes.
    USBE1CSR3bits.RXINTERV = 0x01; // Poll every microframe (8th of a frame)
    USBE2CSR2bits.TXINTERV = 0x04; // Poll every 8 microframes (once per frame)
    
    // MULT<4:0>: Multiplier Control bits
    // For Isochronous/Interrupt endpoints or of packet splitting on Bulk 
    // endpoints, multiplies RXMAXP/TXMAXP by MULT+1 for the payload size.
    // For Bulk endpoints, MULT can be up to 32 and defines the number of ?USB? 
    // packets of the specified payload into which a single data packet placed 
    // in the FIFO should be split, prior to transfer. The data packet is 
    // required to be an exact multiple of the payload specified by TXMAXP.
    // For Isochronous/Interrupts endpoints operating in Hi-Speed mode, MULT may 
    // be either 2 or 3 and specifies the maximum number of such transactions 
    // that can take place in a single microframe.
    USBE1CSR1bits.MULT = 3; // RX
    
    // NOTE: We don't set the TX speed in device mode, as noted below from the 
    // data sheet (DS60001320D-page 223):
    // TX Endpoint Operating Speed Control bits (Host mode)
    // In HOST mode it would use CSR2 to set the TX speed, for example:
    // USBExCSR2bits.SPEED = z; 
    // Where x is the endpoint number and z is the speed.
    // USBEnCSR2 for TX endpoint, USBEnCSR3 for RX endpoint
    USBE0CSR2bits.SPEED = 1;        // Endpoint 0 Operating Speed Control bits
    USBE1CSR3bits.SPEED = 1;        // Endpoint 1: RX Endpoint Operating Speed Control bits - High speed
     
    // ISO: Isochronous Endpoint Control bit (Device mode)
    // 1 = Enable the TX/RX endpoint for Isochronous transfers 
    // 0 = Enable the TX/RX endpoint for Bulk/Interrupt transfers
    // USBEnCSR0 for TX endpoint, USBEnCSR1 for RX endpoint
    USBE1CSR1bits.ISO = 1;      // Isochronous RX Endpoint Enable bit (Device mode).
    USBE2CSR0bits.ISO = 1;      // Isochronous TX Endpoint Enable bit (Device mode).
    
    /* Enable Endpoint interrupts */
    USBCSR1bits.EP0IE = 1;      // Endpoint 0 interrupt enable
    USBCSR2bits.EP1RXIE = 1;    // Endpoint 1 RX interrupt enable
    USBCSR1bits.EP2TXIE = 1;    // Endpoint 2 TX interrupt enable
    
    USBCSR2bits.SOFIE = 0;      // Enable Start of Frame event interrupt.
    
    USBCSR2bits.RESETIE = 1; 
    
    //IEC4bits.USBDMAIE = 1;      // Enable USB DMA interrupt.
    USBCRCONbits.USBIE = 1;     // Enable general interrupt from USB module.
    IEC4bits.USBIE = 1;         // Enable the USB interrupt.
}

int connectUSB(){
    USBCSR0bits.SOFTCONN = 1;
    led_3 = 1;  // USB Enabled
    return 1;
}

int disableUSB(){
    USBCSR0bits.SOFTCONN = 0;
    led_3 = 0;  // USB Disabled
    return 0;
}

void setAddress(volatile uint8_t usbAddress){
    // The Set_Address request changes the address after the status stage. 
    // You must update the FUNC field only after you get the status interrupt.
    USBCSR0bits.FUNC = usbAddress & 0x7F;
}

void controlTrans(){ // USB Request Handler - USB Audio 2.0
    
    switch (bmbRequest) {
       
       	case 0x0001:{ // Clear Feature
            USBE0CSR0bits.STALL = 1;
        }
        break;
            
       	case 0x0101:{ // Clear Feature - Interface
            switch(ep0data[4]){
                case 0x01:{
                    clearFeatureInterface1 = ep0data[2];
                }
                break;
            }
        }
        break;
            
       	case 0x0201:{ // Clear Feature - Endpoint
            switch(ep0data[4]){
                case 0x01:{
                    clearFeatureEndpoint1 = ep0data[2];
                }
                break;
            }
        }
        break;
            
        case 0x8008:{ // Get Configuration
            ep0BlockData = &usbConfiguration;
            txBlock_ep0(sizeof(ep0BlockData));
        }
        break;
            
        case 0x8006:{  
            switch (ep0data[3]) {
                case 0x00: { // Undefined
                        USBE0CSR0bits.STALL = 1;
                    }
                break;
                
                case 0x01: { // Device Descriptor
                        ep0BlockData = Dev_desc;
                        txBlock_ep0(sizeof(Dev_desc));
                    }
                break;

                case 0x02:{ // Configuration Descriptor
                   /* Per the USB Specifications:
                    * A request for a configuration descriptor returns the 
                    * configuration descriptor, all interface descriptors, and 
                    * endpoint descriptors for all of the interfaces in a single 
                    * request. The first interface descriptor follows the 
                    * configuration descriptor. 
                    * 
                    * The endpoint descriptors for the first interface follow the 
                    * first interface descriptor. 
                    * 
                    * If there are additional interfaces, their interface 
                    * descriptor and endpoint descriptors follow the first 
                    * interface's endpoint descriptors. 
                    * 
                    * Class-specific and/or vendor-specific descriptors follow the 
                    * standard descriptors they extend or modify.
                    * 
                    * All devices must provide a device descriptor and at least one 
                    * configuration descriptor. If a device does not support a 
                    * requested descriptor, it responds with a Request Error.
                    */   
                    ep0BlockData = DescriptorArray;
                    txBlock_ep0(wLength);
                    led_4b = 0;
                    }
                break;

                case 0x03:{ // String Descriptors
                        switch (ep0data[2]) {  
                            case 0x00: { // Language ID
                                ep0BlockData = string0;
                                txBlock_ep0(sizeof(string0));
                            }
                            break;

                            case 0x01: { // Manufacturer
                                ep0BlockData = string1;
                                txBlock_ep0(sizeof(string1));
                            }
                            break;

                            case 0x02: { // Product
                                ep0BlockData = string2;
                                txBlock_ep0(sizeof(string2));
                            }
                            break;

                            case 0x03: { // Serial
                                ep0BlockData = string3;
                                txBlock_ep0(sizeof(string3));
                            }
                            break;
                          
                            case 0x04: { // 
                                ep0BlockData = string4;
                                txBlock_ep0(sizeof(string4));
                            }
                            break;
                                
                            case 0x05: { //
                                ep0BlockData = string5;
                                txBlock_ep0(sizeof(string5));
                            }
                            break;
                            
                            case 0x06: { //
                                ep0BlockData = string6;
                                txBlock_ep0(sizeof(string6));
                            }
                            break;
                            
                            case 0x07: { //
                                ep0BlockData = string7;
                                txBlock_ep0(sizeof(string7));
                            }
                            break;
                            
                            case 0x08: { //
                                ep0BlockData = string8;
                                txBlock_ep0(sizeof(string8));
                            }
                            break;
                            
                            case 0x09: { //
                                ep0BlockData = string9;
                                txBlock_ep0(sizeof(string9));
                            }
                            break;
                                
                        } // End of case ep0data[2] switch
                        break;
                        
                    } // End of case 0x03 switch - String Descriptors
                break;
                
                case 0x04:{  // Get Interface
                    switch (ep0data[2]){
                            
                        case 0x00:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x01:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x02:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x03:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                    }
                    
                } // End of case 0x04 switch
                break;
                    
                case 0x05:{  // Get Endpoint
                    switch (ep0data[2]){
                        
                        case 0x00:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x01:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x02:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x03:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x04:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x05:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x06:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                            
                        case 0x07:{
                            USBE0CSR0bits.STALL = 1;
                        }
                        break;
                    }
                } // End of case 0x05 switch
                break;
                
                case 0x06:{ // Device Qualifier Descriptor
                    ep0BlockData = DeviceQualifierDesc;
                    txBlock_ep0(sizeof(DeviceQualifierDesc));
                }
                break;
            } // End of switch ep0data[3]
            
        } // End of case 0x8006 - Get Descriptor(s).
        break;
            
        case 0x810A:{ // Get Interface - returns the current bAlternateSetting value.
            switch (ep0data[4]) {
                case 0x01: { // Audio Streaming Interface #1
                ep0BlockData = &usbStreamingInterface1_AltSetting;
                txBlock_ep0(sizeof(usbStreamingInterface1_AltSetting));
                }
                break;
            } // End of switch ep0data[5].
            
        } // End of case 0x810A
        break;
        
        case 0x8000:{ // Get Status - Device
            ep0BlockData = doubleZero;
            txBlock_ep0(sizeof(doubleZero));
        }
        break;
            
        case 0x8100:{ // Get Status - Interface
            ep0BlockData = doubleZero;
            txBlock_ep0(sizeof(doubleZero));
        }
        break;
            
        case 0x8200:{ // Get Status - Endpoint
            ep0BlockData = doubleZero;
            txBlock_ep0(sizeof(doubleZero));
        }
        break;
            
        case 0x0005:{ // Save Address
            USBE0CSR0bits.RXRDYC = 1;
            USBE0CSR0bits.DATAEND = 1;
            usbAddress = ep0data[2];
            setDevAddr = TRUE;
        }
        break;
            
        case 0x0009:{ // Set Configuration
            usbConfiguration = ep0data[2]; // wValue
        }
        break;
            
        case 0x0007:{ // Set Descriptor
            getUSB_ep0(wLength);
            // wValue contains the Descriptor Type and Descriptor Index.
            // The new descriptor data needs to be copied and saved.
        }
        break;
            
        case 0x0003:{ // Set Feature - Zero
            setFeatureZero = ep0data[2];
        }
        break;
            
        case 0x0103:{ // Set Feature - Interface
            setFeatureInterface = ep0data[2];
        }
        break;
            
        case 0x0203:{ // Set Feature - Endpoint
            setFeatureEndpoint = ep0data[2];
        }
        break;
            
        case 0x010B:{ // Set Interface
            switch (ep0data[4]){ // (wIndex)
                case 0x01: { // Audio Streaming Interface #1
                    usbStreamingInterface1_AltSetting = ep0data[2]; // (wValue)
                    // Turn on/off I2S Audio Interface
                    SPI2CONbits.ON = usbStreamingInterface1_AltSetting; 
                    // Enable/Disable DMA Channels for interface #1
                    ////DCH0CONbits.CHEN = usbStreamingInterface1_AltSetting; // DMA Channel 0
                    DCH1CONbits.CHEN = usbStreamingInterface1_AltSetting; // DMA Channel 1
                }
                break;
            }
        }
        break;
               
        case 0x820C:{ // Synchronize Frame
            getUSB_ep0(wLength);
            FrameNumber = (uint16_t)(ep0temp[1] << 8) | (uint16_t)(ep0temp[0]);
        }
        break;
        
        /*********************************************************************
         Audio MIDI Class Request
        *********************************************************************/
        case 0x2101:{ // Set Current Interface
            // This was structured for ease of reading/understanding.
            // So some parts may seem redundant or could possibly be
            // structured more simply but that may make it more
            // difficult to follow the order of operation.
            switch(ep0data[3]){
                case 0x01:{ // Mute Control
                    switch (ep0data[2]){ // Channel Number
                        
                        case 0x00:{ // Set Mute - Master
                            switch (ep0data[5]){
                                
                                case 0x02:{ // Feature Unit 2 - Master Mute - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    muteMasterOut_featUnit2 = ep0temp[0];
                                }
                                break;    
                        
                            }
                        }
                        break;
                        
                        case 0x01:{ // Set Mute - Left
                            switch (ep0data[5]){
                                
                                case 0x02:{ // Feature Unit 2 - Left Mute - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    muteChannel1Out_featUnit2 = ep0temp[0];
                                }
                                break;    
                        
                            }
                        }
                        break;
                        
                        case 0x02:{ // Set Mute - Right
                            switch (ep0data[5]){
                                
                                case 0x02:{ // Feature Unit 2 - Right Mute - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    muteChannel2Out_featUnit2 = ep0temp[0];
                                }
                                break;    
                        
                            }
                        }
                        break;
                    }
                }
                break;
                
                case 0x02:{
                    switch(ep0data[2]){ // Volume Control
                        case 0x00:{ // Channel 0 - Master
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Master Volume - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    volumeMasterOut_featUnit2[0] = ep0temp[0];
                                    volumeMasterOut_featUnit2[1] = ep0temp[1];
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x01:{ // Left Volume
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Left Volume - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    volumeChannel1Out_featUnit2[0] = ep0temp[0];
                                    volumeChannel1Out_featUnit2[1] = ep0temp[1];
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x02:{ // Right Volume
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Right Volume - Channel 2
                                    getUSB_ep0(ep0data[6]);
                                    volumeChannel2Out_featUnit2[0] = ep0temp[0];
                                    volumeChannel2Out_featUnit2[1] = ep0temp[1];
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }
        break;

        
        case 0x2201:{ // Set Current Endpoint 
            switch (ep0data[3]) {
                    
                case 0x01:{ // SAMPLING_FREQ_CONTROL
                    // Receive the 3 bytes specifying the sample rate
                    getUSB_ep0(ep0data[6]);
                    switch (ep0data[4] & 0x0F){
                        case 0x01:{ // This should match the respective Endpoint number
                            sampleRate1 = (ep0temp[2] << 16) | (ep0temp[1] << 8) | ep0temp[0];
                            samplesPerSOF_IF1 = sampleRate1 / uFrameHZ;
                            SPI2BRG = (FPb2 / 2 * (sampleRate1 * AudioBits)) - 1;
                        }
                        break;
                    }
                }
                break;
            }
        }
        break;
         
        case 0xA181:{ // Get Current - Interface
            switch(ep0data[3]){
                case 0x01:{ // MUTE CONTROL
                    switch(ep0data[2]){ // Mute Controls - Master, Left, Right
                        case 0x00:{ // Channel 0 - Master Mute
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Master Mute
                                    ep0BlockData = &muteMasterOut_featUnit2;
                                    txBlock_ep0(sizeof(muteMasterOut_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x01:{ // Channel 1 - Left Mute Control
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Left Mute
                                    ep0BlockData = &muteChannel1Out_featUnit2;
                                    txBlock_ep0(sizeof(muteChannel1Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x02:{ // Channel 2 - Right
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Right Mute
                                    ep0BlockData = &muteChannel2Out_featUnit2;
                                    txBlock_ep0(sizeof(muteChannel2Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
                
                case 0x02:{ // GET VOLUME CONTROLS
                    switch(ep0data[2]){ // Volume Controls - Master, Left, Right
                        case 0x00:{ // Channel 0 - Master Volume
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Get Master Volume - Channel 2
                                    ep0BlockData = volumeMasterOut_featUnit2;
                                    txBlock_ep0(sizeof(volumeMasterOut_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x01:{ // Channel 1 - Get Left Volume Control
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Get Left Volume - Channel 2
                                    ep0BlockData = volumeChannel1Out_featUnit2;
                                    txBlock_ep0(sizeof(volumeChannel1Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x02:{ // Channel 2 - Get Right
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Get Right Volume - Channel 2
                                    ep0BlockData = volumeChannel2Out_featUnit2;
                                    txBlock_ep0(sizeof(volumeChannel2Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                    }
                    
                }
                break;
            } // end of switch ep0data[3]
        }
        break;
        
        case 0xA281:{ // Get Current - Endpoint - SAMPLE FREQUENCY
            switch(ep0data[3]){
                
                case 0x01:{
                    switch(ep0data[4] & 0x0F){
                        case 0x01:{ // Endpoint Address
                            conv32to8[0] = (uint8_t)(sampleRate1 & 0x000000FF);
                            conv32to8[1] = (uint8_t)((sampleRate1 & 0x0000FF00) >> 8);
                            conv32to8[2] = (uint8_t)((sampleRate1 & 0x00FF0000) >> 16);
                            ep0BlockData = conv32to8;
                            txBlock_ep0(sizeof(conv32to8));
                            }
                        break;
                    }
                }
                break;
            }
        }
        break;
        
        case 0x2102:{ // Set Minimum - Interface
            // This was structured for ease of reading/understanding.
            // So some parts may seem redundant or could possibly be
            // structured more simply but that may make it more
            // difficult to follow the order of operation.
            switch(ep0data[2]){ // Volume Control
                case 0x00:{ // Channel 0 - Master
                    switch(ep0data[5]){ // Feature Unit
                        
                        case 0x02:{ // Feature Unit 2 - Master Volume
                            getUSB_ep0(ep0data[6]);
                            minMasterOut_featUnit2[0] = ep0temp[0];
                            minMasterOut_featUnit2[1] = ep0temp[1];
                        }
                        break;
                    }
                }
                break;
                
                case 0x01:{ // Channel 1 - Left
                    switch(ep0data[5]){ // Feature Unit
                        
                        case 0x02:{ // Feature Unit 2 - Left Volume
                            getUSB_ep0(ep0data[6]);
                            minChannel1Out_featUnit2[0] = ep0temp[0];
                            minChannel1Out_featUnit2[1] = ep0temp[1];
                        }
                        break;
                    }
                }
                break;
                
                case 0x02:{ // Channel 2 - Right
                    switch(ep0data[5]){ // Feature Unit
                        
                        case 0x02:{ // Feature Unit 2 - Left Volume
                            getUSB_ep0(ep0data[6]);
                            minChannel2Out_featUnit2[0] = ep0temp[0];
                            minChannel2Out_featUnit2[1] = ep0temp[1];
                        }
                        break;
                    }
                }
                break;
            }
        }
        break;
        
        case 0x2202:{ // Set Minimum - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA182:{ // Get Minimum - Interface
            // This was structured for ease of reading/understanding.
            // So some parts may seem redundant or could possibly be
            // structured more simply but that may make it more
            // difficult to follow the order of operation.
            switch(ep0data[3]){
                
                case 0x02:{ // VOLUME MINIMUM
                    switch(ep0data[2]){ // Volume Minimums - Master, Left, Right
                        case 0x00:{ // Channel 0 - Master Minimum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Master Volume Minimum
                                    ep0BlockData = minMasterOut_featUnit2;
                                    txBlock_ep0(sizeof(minMasterOut_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x01:{ // Channel 1 - Left Volume Minimum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Left Minimum
                                    ep0BlockData = minChannel1Out_featUnit2;
                                    txBlock_ep0(sizeof(minChannel1Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                
                        case 0x02:{ // Channel 2 - Right Volume Minimum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Right Volume Minimum
                                    ep0BlockData = minChannel2Out_featUnit2;
                                    txBlock_ep0(sizeof(minChannel2Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                    }
                    
                }
                break;
            } // end of switch(ep0data[3])
        }
        break;
        
        case 0xA282:{ // Get Minimum - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2103:{ // Set Maximum - Interface
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2203:{ // Set Maximum - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA183:{ // Get Maximum - Interface
            // This was structured for ease of reading/understanding.
            // So some parts may seem redundant or could possibly be
            // structured more simply but that may make it more
            // difficult to follow the order of operation.
            switch(ep0data[3]){
                
                case 0x02:{ // VOLUME MAXIMUM
                    switch(ep0data[2]){ // Volume Maximums - Master, Left, Right
                        case 0x00:{ // Channel 0 - Master Maximum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Master Volume Maximum
                                    ep0BlockData = maxMasterOut_featUnit2;
                                    txBlock_ep0(sizeof(maxMasterOut_featUnit2));
                                }
                                break;
                            }
                        }
                
                        case 0x01:{ // Channel 1 - Left Volume Maximum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Left Maximum
                                    ep0BlockData = maxChannel1Out_featUnit2;
                                    txBlock_ep0(sizeof(maxChannel1Out_featUnit2));
                                }
                                break;
                            }
                        }
                
                        case 0x02:{ // Channel 2 - Right Volume Maximum
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Right Volume Maximum
                                    ep0BlockData = maxChannel2Out_featUnit2;
                                    txBlock_ep0(sizeof(maxChannel2Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                    }
                    
                }
                break;
            } // end of switch(ep0data[3])
        }
        break;
        
        case 0xA283:{ // Get Maximum - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2104:{ // Set Resolution - Interface
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2204:{ // Set Resolution - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA184:{ // Get Resolution - Interface
            // This was structured for ease of reading/understanding.
            // So some parts may seem redundant or could possibly be
            // structured more simply but that may make it more
            // difficult to follow the order of operation.
            switch(ep0data[3]){
                
                case 0x02:{ // GET RESOLUTION 
                    switch(ep0data[2]){ // Volume Resolution - Master, Left, Right
                        case 0x00:{ // Channel 0 - Master Resolution
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Master Volume Resolution
                                    ep0BlockData = resolutionMasterOut_featUnit2;
                                    txBlock_ep0(sizeof(resolutionMasterOut_featUnit2));
                                }
                                break;
                            }
                        }
                
                        case 0x01:{ // Channel 1 - Left Volume Resolution
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Left Resolution
                                    ep0BlockData = resolutionChannel1Out_featUnit2;
                                    txBlock_ep0(sizeof(resolutionChannel1Out_featUnit2));
                                }
                                break;
                            }
                        }
                
                        case 0x02:{ // Channel 2 - Right Volume Resolution
                            switch(ep0data[5]){ // Feature Unit
                                
                                case 0x02:{ // Feature Unit 2 - Right Volume Resolution
                                    ep0BlockData = resolutionChannel2Out_featUnit2;
                                    txBlock_ep0(sizeof(resolutionChannel2Out_featUnit2));
                                }
                                break;
                            }
                        }
                        break;
                    }
                    
                }
                break;
            } // end of switch(ep0data[3])
        }
        break;
        
        case 0xA284:{ // Get Resolution - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2105:{ // Set Memory - Interface
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0x2205:{ // Set Memory - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA185:{ // Get Memory - Interface
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA285:{ // Get Memory - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA1FF:{ // Get Status - Interface
            USBE0CSR0bits.STALL = 1;
        }
        break;
        
        case 0xA2FF:{ // Get Status - Endpoint
            USBE0CSR0bits.STALL = 1;
        }
        break;
            
        /*********************************************************************
         USB Test Mode - Required for high speed compliance testing
        *********************************************************************/
        case 0x2300:{ // 
            switch (ep0data[3]) {
                case 0x01:{ // Test J
                //USBCSR3bits.TESTJ    
                }
                break;
                
                case 0x02:{ // Test K
                //USBCSR3bits.TESTK    
                }
                break;
                
                case 0x03:{ // Test_SE0_NAK
                //USBCSR3bits.NAK   
                }
                break;
                
                case 0x04:{ // Test_Packet
                //USBCSR3bits.PACKET    
                }
                break;
                
                case 0x05:{ // Test_Force_Enable - Only used in HOST mode
                //USBCSR3bits.FORCEHST    // Forces USB module into Host mode, 
                                        // regardless of whether it is connected to any peripheral. 
                //USBCSR3bits.FORCEFS // <- For Full Speed mode, or
                //USBCSR3bits.FORCEHS // <- For High Speed mode
                }
                break;
                            
            }
        }
        break;
    
        default:{
            USBE0CSR0bits.STALL = 1;
            }
        break;        
    }

    return;
}

int getUSB_ep0(uint16_t numBytes){
    int timeout_ep0 = 0;
    do{
        timeout_ep0++;
    }while(!USBE0CSR0bits.RXRDY && (timeout_ep0 < 100));
    
    ep0rbc = USBE0CSR2bits.RXCNT; // Endpoint 0 - Received Bytes Count
    
    tempData = (uint8_t *)&USBFIFO0;
               
                for(i = 0; i < numBytes; i++){
                    ep0temp[i] = *(tempData + (i & 3));
                }
            
            USBE0CSR0bits.RXRDYC = 1;
            return (ep0rbc);
            
            
}

void putUSB_ep0(uint8_t ep0data, uint8_t end){
            volatile uint8_t *ep0fifo = NULL;
            ep0fifo = (uint8_t *)&USBFIFO0;
            
                *ep0fifo = ep0data;
            
            if(end == 1)
                {
                    USBIE0CSR0bits.DATAEND = 1; // End of Data Control bit (Device mode) 
                    // The software sets this bit when:
                    // * Setting TXPKTRDY for the last data packet
                    // * Clearing RXPKTRDY after unloading the last data packet 
                    // * Setting TXPKTRDY for a zero length data packet
                    // Hardware clears this bit.
                }
            
                USBE0CSR0bits.TXRDY = 1;
}

int txBlock_ep0(uint16_t NumBytes){
    
    volatile uint8_t *ep0fifo = NULL;
    ep0fifo = (uint8_t *)&USBFIFO0;
    uint16_t ep0ArraySize = sizeof(ep0BlockData);
    char setEnd = FALSE;
    
    packetSize_ep0 = NumBytes;
    if(packetSize_ep0 > EP0_MAX_PACKET_SIZE)
        {
            packetSize_ep0 = EP0_MAX_PACKET_SIZE;
        }
    ep0RemainingBytes = NumBytes;

    ep0ArrPos = 0; // Reset the array position.
    do{
        
            int timeout = 0;
            do{
                timeout++;
            }while(USBE0CSR0bits.TXRDY && timeout < 400);
            
            if(timeout >= 400){
                return -1;
            }
            
            if(ep0RemainingBytes < packetSize_ep0){ // Check if this is  last packet
                packetSize_ep0 = ep0RemainingBytes;
                setEnd = TRUE;
            }
            
            for(i = 0; i < packetSize_ep0; i++) {
                *ep0fifo = ep0BlockData[ep0ArrPos++];
                ep0RemainingBytes--;
            }
            
            if(setEnd == TRUE)
                {
                    USBIE0CSR0bits.DATAEND = 1; // End of Data Control bit (Device mode) 
                    // The software sets this bit when:
                    // * Setting TXPKTRDY for the last data packet
                    // * Clearing RXPKTRDY after unloading the last data packet 
                    // * Setting TXPKTRDY for a zero length data packet
                    // Hardware clears this bit.
                }
            USBE0CSR0bits.TXRDY = 1;
            
    }while(ep0RemainingBytes != 0);
    
return 0;
}

uint16_t rxAudioISO_ep1(){
    tempData = (uint8_t *)&USBFIFO1;
    int i;   
            for(i = 0; i < ep1rbc; i++){
                USB_EP1_buffer[i] = *(tempData + (i & 3));
            }
    
        // CHCSIZ<15:0>: Channel Cell-Size bits
        // 1111111111111111 = 65,535 bytes transferred on an event 
        // ?
        // ?
        // ?
        // 0000000000000010 = 2 bytes transferred on an event 
        // 0000000000000001= 1 byte transferred on an event 
        // 0000000000000000 = 65,536 bytes transferred on an event
        DCH1CSIZbits.CHCSIZ = ep1rbc;
        
        // CHEN: Channel Enable bit(2)
        // 1 = Channel is enabled 
        // 0 = Channel is disabled    
        DCH1CONbits.CHEN = 1; // DMA Channel 3 is Enabled.
        
        // CFORCE: DMA Forced Transfer bit
        // 1 = A DMA transfer is forced to begin when this bit is written to a '1' 
        // 0 = This bit always reads '0'
        DCH1ECONbits.CFORCE = 1;
    
    return ep1rbc;
}

int txFeedback_ep2(uint32_t feedbackValue){
    
    int timeout_ep2 = 0;
            do{
                timeout_ep2++;
            }while(USBE2CSR0bits.TXPKTRDY && timeout_ep2 < 400);
            
            if(timeout_ep2 >= 400){
                return -1;
            }
    
    USBFIFO2 = feedbackValue;
            
    USBE2CSR0bits.TXPKTRDY = 1;
            
    
return 0;
}
