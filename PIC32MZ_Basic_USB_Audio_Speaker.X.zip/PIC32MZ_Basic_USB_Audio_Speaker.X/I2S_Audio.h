/*
 * File name: I2S_Audio.h for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#ifndef _I2S_AUDIO_H    /* Guard against multiple inclusion */
#define _I2S_AUDIO_H

#define SampleWidth 32              // Number of bits per sample, e.g.- 16, 24, or 32
#define AudioBits (SampleWidth * 2) // Left bits (32) + Right bits (32)

#include <xc.h>
/***** Audio Endpoint Feedback Related Variables *****/
uint32_t currentValueTimer7;
uint32_t currentValueTimer9;
uint32_t previousValueTimer7;
uint32_t previousValueTimer9;
uint32_t calcValueTimer7;
uint32_t calcValueTimer9;
uint32_t feedbackIN;
uint32_t feedbackOUT;

/************* Declare functions *************/
void initI2S2(uint8_t clockSourceI2S2);
/******** End of Function Declarations *******/

#endif /* _I2S_AUDIO_H */

/* *****************************************************************************
 End of File
 */
