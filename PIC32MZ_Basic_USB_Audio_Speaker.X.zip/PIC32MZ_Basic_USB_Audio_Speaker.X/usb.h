/*
 * File name: usb.h for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#ifndef _USB_H    /* Guard against multiple inclusion */
#define _USB_H

/* Uncomment to use USB DMA, presently it's not working correctly */
//#define useUSBDMA

/* USB related values */
#define EP0BUFFSIZE     8   // In multiples of 8, e.g.- 8 (x8) equals a size of 64
#define EP1RXBUFFSIZE   128 // Also in multiples of 8, e.g.- 128 (x8) equals a size of 1024
#define EP2TXBUFFSIZE   1   // Also in multiples of 8, e.g.- 1 (x8) equals a size of 8

#define EP0_MAX_PACKET_SIZE  (EP0BUFFSIZE * 8)
#define EP1_MAX_PACKET_SIZE  (EP1RXBUFFSIZE * 8)
#define EP2_MAX_PACKET_SIZE  (EP2TXBUFFSIZE * 8)

#define VBUS_VALID 0x3

/***** Descriptor Types *****/
#define DEVICE  0x01
#define CONFIG  0x02
#define INTERFACE   0x04
#define CS_INTERFACE    0x24
#define END_POINT    0x05
#define CS_ENDPOINT 0x25
#define STRING  0x03
/***** Descriptor Sub-Types *****/
#define HEADER  0x01
#define INPUT_TERMINAL  0x02
#define OUTPUT_TERMINAL 0x03
#define FEATURE_UNIT    0x06   
#define MS_HEADER   0x01
#define FORMAT_TYPE 0x02
/***** Interface Class *****/
#define AUDIO   0x01
/***** Interface Sub-Class *****/
#define AUDIO_CONTROL   0x01
#define AUDIO_STREAMING 0x02
#define MIDIStreaming   0x03
/***** Sample Rates/Limits *****/
#define MAX_SAMPLE_RATE 0x017700
#define SAMPLE_RATE_2   0x015888
#define SAMPLE_RATE_3   0x00BB80
#define MIN_SAMPLE_RATE 0x00AC44
#define uFrameHZ        8000

/*********** General Variable Declarations ***********/
volatile int ep0rbc;        // Endpoint 0 - Received Bytes Count (USB).
volatile int ep1rbc;        // Endpoint 1 - Received Bytes Count (USB).
volatile int ep2rbc;        // Endpoint 2 - Received Bytes Count (USB).

//int ep0_lastRcvdBytesCount;
uint16_t ep0RemainingBytes;
uint16_t ep1RemainingBytes;
uint16_t ep2RemainingBytes;

int epBufSize[8];   // Endpoint Buffers Size.
uint16_t packetSize_ep0, packetSize_ep1, packetSize_ep2;
uint16_t NumBytes, SecBytes;
uint8_t numOfConfigRequest;

uint8_t *ep0BlockData;
uint32_t *ep1BlockData;
uint8_t *ep2BlockData;

uint8_t *ep0usbData;
uint32_t *ep1usbData;
uint8_t *ep2usbData;

uint8_t usbStreamingInterface1;
uint8_t usbStreamingInterface1_AltSetting;
uint8_t usbControlInterface;
uint8_t usbConfiguration;
uint8_t usbInterface;
uint8_t setFeatureZero;
uint8_t setFeatureInterface;
uint8_t setFeatureEndpoint;
uint16_t FrameNumber;
extern uint8_t doubleZero[2];

// USB end point data - The corresponding array should be the same length as its
// FIFO size.
uint8_t ep0data[(EP0BUFFSIZE * 8)]; // USB end point 0 data
uint8_t ep0temp[(EP0BUFFSIZE * 8)]; // USB end point 0 temp cache

uint32_t ep1data[(EP1RXBUFFSIZE * 8)]; // USB end point 1 data 
uint8_t ep2data[(EP2TXBUFFSIZE * 8)]; // USB end point 2 data 

volatile uint8_t *tempData;
volatile uint32_t *tempData32t;
uint16_t bmbRequest; // bmRequestType, bRequest
uint16_t wValue;
uint16_t wIndex;
uint16_t wLength;
volatile uint8_t usbAddress;
volatile uint8_t setDevAddr;

uint16_t ep0ArrPos;
uint16_t ep1ArrPos;
uint16_t ep2ArrPos;

uint16_t ep0SentBytes;
uint16_t ep1SentBytes;
uint16_t ep2SentBytes;

// Audio Parameters
uint32_t sampleRate1; // Audio Sample Rate 1
uint16_t samplesPerSOF_IF1;

uint8_t conv32to8[4];

uint8_t clearFeatureInterface1;
uint8_t clearFeatureEndpoint1;

uint8_t muteMasterOut_featUnit2;

uint8_t muteChannel1Out_featUnit2;
uint8_t muteChannel2Out_featUnit2;

uint8_t mainVolume_featUnit2[2];

uint8_t volumeMasterOut_featUnit2[2];


uint8_t volumeChannel1Out_featUnit2[2];
uint8_t volumeChannel2Out_featUnit2[2];

uint8_t minMasterOut_featUnit2[2];
uint8_t minChannel1Out_featUnit2[2];
uint8_t minChannel2Out_featUnit2[2];

uint8_t maxMasterOut_featUnit2[2];
uint8_t maxChannel1Out_featUnit2[2];
uint8_t maxChannel2Out_featUnit2[2];

uint8_t resolutionMasterOut_featUnit2[2];
uint8_t resolutionChannel1Out_featUnit2[2];
uint8_t resolutionChannel2Out_featUnit2[2];


// USB Audio related variables
uint32_t syncFeedback;
uint32_t lastTimerValue;
uint32_t currentTimerValue;
uint32_t samplingInterval;

// USB Audio Sync Encoding Format 16.16 Variables
uint16_t samplesPerMicroFrame;  /* Upper 16 bits, often rounded to 12 bits */
uint16_t fractionSample;        /* Lower 16 bits, often rounded to 13 bits  */


// 
uint16_t i;



void initUSB(void);
int connectUSB();
int disableUSB();
void setAddress(volatile uint8_t usbAddress);
void controlTrans();
int getUSB_ep0(uint16_t numBytes);
void putUSB_ep0(uint8_t ep0data, uint8_t end);
int txBlock_ep0(uint16_t NumBytes);
uint16_t rxAudioISO_ep1();
int txFeedback_ep2(uint32_t feedbackValue);



#endif /* _USB_H */

/* *****************************************************************************
 End of File
 */
