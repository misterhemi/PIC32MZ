/*
 * File name: dma.c for PIC32MZ Basic USB Audio Speaker
 * Released under FreeBSD License 
 * 
 * (C)2020 - Mark Serran Lewis 
 * mark@lewistechnogroup.com, misterhemi@yahoo.com
 * All rights reserved.
 * 
 * This is only an example, it is a very stripped down version from
 * some of my own proprietary code and is given here as an example.
 * It may contain some traces of unused code, in the event I forgot to
 * remove some of the code from my original source.
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without      
 *  modification, are permitted provided that the following conditions are  
 *  met:                                                                    
 *                                                                          
 *  1. Redistributions of source code must retain the above copyright       
 *     notice, this list of conditions and the following disclaimer.        
 *  2. Redistributions in binary form must reproduce the above copyright    
 *     notice, this list of conditions and the following disclaimer in the  
 *     documentation and/or other materials provided with the distribution. 
 *                                                                          
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
 *                                                                          
 *  The views and conclusions contained in the software and documentation   
 *  are those of the authors and should not be interpreted as representing  
 *  official policies, either expressed or implied, of the FreeBSD Project. 
 *
 */

#include <xc.h>
#include <sys/attribs.h>
#include <sys/kmem.h>
#include "dma.h"
#include "InterruptMask.h"

/***** DMA0 Channel and DMA1 Channel are a chained pair *****/
void __attribute__((interrupt(IPL7SRS), at_vector(_DMA0_VECTOR), no_fpu)) _DMA0_Handler(void){
    // CHCCIF: Channel Cell Transfer Complete Interrupt Flag bit
    // 1 = A cell transfer has been completed (CHCSIZ bytes have been transferred)
    // 0 = No interrupt is pending
    if(DCH0INTbits.CHCCIF){
        
        // CHEN: Channel Enable bit(2)
        // 1 = Channel is enabled 
        // 0 = Channel is disabled    
        DCH1CONbits.CHEN = 1; // DMA Channel 1 is Enabled.
        
        // CFORCE: DMA Forced Transfer bit
        // 1 = A DMA transfer is forced to begin when this bit is written to a '1' 
        // 0 = This bit always reads '0'
        DCH1ECONbits.CFORCE = 1; // DMA Channel 1 transfer is forced.
        
        DCH0INTbits.CHCCIF = 0;
    }
    
    DCH0INTCLR = _DCH0INT_MASK;
    IFS4CLR = _IFS4_DMA0_MASK;
}

void __attribute__((interrupt(IPL7SRS), at_vector(_DMA1_VECTOR), no_fpu)) _DMA1_Handler(void){
    
    
    DCH1INTCLR = _DCH1INT_MASK;
    IFS4CLR = _IFS4_DMA1_MASK;
}

// Remember to change the USB configuration and ISR interrupt priority to 1
void initDMA(){
    // From datasheet DS60001320E, Pages: 189 to 204
    
    // DMA module On bit
    // 1 = DMA module is enabled
    // 0 = DMA module is disabled
    DMACONbits.ON = 0;
    
    // Unlock sequence
    SYSKEY = 0xAA996655; // Write Key1 to SYSKEY 
    SYSKEY = 0x556699AA; // Write Key2 to SYSKEY
    
    // CFGCON: CONFIGURATION CONTROL REGISTER
    // DMAPRI: DMA Read and DMA Write Arbitration Priority to SRAM bit(1)
    // 1 = DMA gets High Priority access to SRAM
    // 0 = DMA uses Least Recently Serviced Arbitration (same as other initiators)
    CFGCONbits.DMAPRI = 1;
    // Note 1: To change this bit, the unlock sequence must be performed. Refer 
    // to Section 42. 'Oscillators with Enhanced PLL' (DS60001250) in the 
    // 'PIC32 Family Reference Manual' for details.
    
    // Lock sequence
    SYSKEY = 0;
    
    // Disable the interrupts.
    IEC4bits.DMA0IE = 0;
    IEC4bits.DMA1IE = 0;
    
    // Clear the interrupt flags.
    IFS4CLR = _IFS4_DMA0_MASK;
    IFS4CLR = _IFS4_DMA1_MASK;
    
    /*************************************************************************** 
     * Channel 1 off, priority 2, chain to higher priority (channel 0), enable 
     * events detection while disabled 
    **************************************************************************** 
     * Channel 3 off, priority 2, chain to higher priority (channel 2), enable 
     * events detection while disabled 
     **************************************************************************/
    // CHPRI<1:0>: Channel Priority bits 
    // 11 = Channel has priority 3 (highest) 
    // 10 = Channel has priority 2
    // 01 = Channel has priority 1
    // 00 = Channel has priority 0
    DCH0CONbits.CHPRI = 3;
    DCH1CONbits.CHPRI = 3;
    
    // CHCHN: Channel Chain Enable bit
    // 1 = Allow channel to be chained
    // 0 = Do not allow channel to be chained
    DCH0CONbits.CHCHN = 0;
    DCH1CONbits.CHCHN = 0;
    
    // CHAED: Channel Allow Events If Disabled bit
    // 1 = Channel start/abort events will be registered, even if the channel is disabled 
    // 0 = Channel start/abort events will be ignored if the channel is disabled
    DCH1CONbits.CHAED = 0;
    
    // DMA CHANNEL x CONTROL REGISTER
    DCH0CON = 0x0000;
    DCH1CON = 0x0000;
    
    // DMA CRC CONTROL REGISTER
    DCRCCON = 0x00; //
    
    // DMA CHANNEL x EVENT CONTROL REGISTER
    DCH0ECON = 0x00;
    DCH1ECON = 0x00;
    
    // Configure DMA0 Source and Destination Addresses.
    //DCH0SSAbits.CHSSA = KVA_TO_PA(&SPI3BUF);          // DMA0 source address.
    //DCH0DSAbits.CHDSA = KVA_TO_PA(&USB_EP1_buffer);   // DMA0 destination address.
    
    // Configure DMA1 Source and Destination Addresses.
    DCH1SSAbits.CHSSA = KVA_TO_PA(&USB_EP1_buffer);   // DMA1 source address.
    DCH1DSAbits.CHDSA = KVA_TO_PA(&SPI2BUF);          // DMA1 destination address.
    
    // CHSSIZ<15:0>: Channel Source Size bits
    // 1111111111111111 = 65,535 byte source size 
    // ?
    // ?
    // ?
    // 0000000000000010 = 2 byte source size 
    // 0000000000000001 = 1 byte source size 
    // 0000000000000000 = 65,536 byte source size
    DCH0SSIZbits.CHSSIZ = 4;    // DMA0 Source register size. I2S In -> EP1 Buffer
    DCH1SSIZbits.CHSSIZ = 1;    // DMA1 Source register size. EP3 Buffer -> I2S Out
    
    // CHDSIZ<15:0>: Channel Destination Size bits
    // 1111111111111111 = 65,535 byte source size 
    // ?
    // ?
    // ?
    // 0000000000000010 = 2 byte source size 
    // 0000000000000001 = 1 byte source size 
    // 0000000000000000 = 65,536 byte source size
    DCH0DSIZbits.CHDSIZ = 1;    // DMA0 destination register size. I2S In -> EP1 Buffer
    DCH1DSIZbits.CHDSIZ = 4;    // DMA1 destination register size. EP3 Buffer -> I2S Out
    
    // CHCSIZ<15:0>: Channel Cell-Size bits
    // 1111111111111111 = 65,535 bytes transferred on an event 
    // ?
    // ?
    // ?
    // 0000000000000010 = 2 bytes transferred on an event 
    // 0000000000000001= 1 byte transferred on an event 
    // 0000000000000000 = 65,536 bytes transferred on an event
    //DCH0CSIZbits.CHCSIZ = 4;                   // DMA0 cell register size. I2S In -> I2S Buffer
    //DCH1CSIZbits.CHCSIZ = I2S_DMA_BUFFER_SIZE; // DMA1 cell register size. I2S Buffer -> USB Out
    //DCH2CSIZ = 4;                   // DMA2 cell register size. USB In -> USB Buffer 
    //DCH3CSIZ = USB_DMA_BUFFER_SIZE; // DMA3 cell register size. USB Buffer -> I2S Out
    
    // CHSIRQ<7:0>: Channel Transfer Start IRQ bits(1)
    // 11111111 = Interrupt 255 will initiate a DMA transfer
    // ?
    // ?
    // ?
    // 00000001 = Interrupt 1 will initiate a DMA transfer 
    // 00000000 = Interrupt 0 will initiate a DMA transfer
    // NOTE: E.g. - _SPI2_TX_VECTOR is Interrupt# 144.
    DCH0ECONbits.CHSIRQ = _SPI3_RX_VECTOR;  // DMA0 Transfer Triggered by SPI-3 RX Interrupt.
    DCH1ECONbits.CHSIRQ = _USB_DMA_VECTOR;      // DMA1 Transfer Triggered by USB DMA interrupt.
    //DCH2ECONbits.CHSIRQ = _USB_VECTOR;      // DMA2 Transfer Triggered by USB Interrupt.
    //DCH3ECONbits.CHSIRQ = _SPI2_TX_VECTOR;  // DMA3 Transfer Triggered by SPI-2 TX Interrupt.
    
    // Channel Abort IRQ Enable bit
    // 1 = Channel transfer is aborted if an interrupt matching CHAIRQ occurs
    // 0 = Interrupt number CHAIRQ is ignored and does not terminate a transfer
    DCH0ECONbits.AIRQEN = 0; // Disable DMA0 transfer abort interrupt.
    DCH1ECONbits.AIRQEN = 0; // Disable DMA1 transfer abort interrupt.
    
    // Channel Start IRQ Enable bit
    // 1 = Start channel cell transfer if an interrupt matching CHSIRQ occurs 
    // 0 = Interrupt number CHSIRQ is ignored and does not start a transfer
    DCH0ECONbits.SIRQEN = 1; // Enable DMA0 transfer start interrupt.
    DCH1ECONbits.SIRQEN = 0; // Disable DMA1 transfer start interrupt.
    
    // CHSDIE: Channel Source Done Interrupt Enable bit
    // 1 = Interrupt is enabled
    // 0 = Interrupt is disabled
    DCH0INTbits.CHSDIE = 1;
    
    // CHCCIE: Channel Cell Transfer Complete Interrupt Enable bit 
    // 1 = Interrupt is enabled
    // 0 = Interrupt is disabled
    DCH0INTbits.CHCCIE = 1;
 
    // Channel Automatic Enable bit
    // 1 = Channel is continuously enabled, and not automatically disabled after 
    //      a block transfer is complete 
    // 0 = Channel is disabled on block transfer complete
    DCH0CONbits.CHAEN = 0;
    DCH1CONbits.CHAEN = 0;
    
    // Clear ALL DMA events and disable interrupts
    DCH0INTCLR = _DMA_CHANNEL_INT_MASK;
    DCH1INTCLR = _DMA_CHANNEL_INT_MASK;
    
    // CHBCIE: Channel Block Transfer Complete Interrupt Enable bit 
    // 1 = Interrupt is enabled
    // 0 = Interrupt is disabled
    DCH0INTbits.CHBCIE = 1;
    DCH1INTbits.CHBCIE = 0;
    
    // CHERIE: Channel Address Error Interrupt Enable bit
    // 1 = Interrupt is enabled
    // 0 = Interrupt is disabled
    DCH0INTbits.CHERIE = 0;
    DCH1INTbits.CHERIE = 0;
    
    // Set DMA0 Interrupt Priority Levet 7, Sub-priority Level 3.
    IPC33bits.DMA0IP = 7;
    IPC33bits.DMA0IS = 3;
    
    // Set DMA1 Interrupt Priority Levet 7, Sub-priority Level 3.
    IPC33bits.DMA1IP = 7;
    IPC33bits.DMA1IS = 3;
    
    // Enable the interrupts.
    IEC4bits.DMA0IE = 1;
    IEC4bits.DMA1IE = 1;
    
    // CHEN: Channel Enable bit(See note 2)
    // 1 = Channel is enabled 
    // 0 = Channel is disabled
    DCH0CONbits.CHEN = 1; // DMA Channel 0 is Enabled.
    DCH1CONbits.CHEN = 1; // DMA Channel 1 is Enabled.
    
    // Enable the DMA module.
    DMACONbits.ON = 1;
    
    // NOTES:
    // 1: The chain selection bit takes effect when chaining is enabled (i.e., CHCHN = 1).
    // 2: When the channel is suspended by clearing this bit, the user 
    //      application should poll the CHBUSY bit (if available on the device 
    //      variant) to see when the channel is suspended, as it may take some 
    //      clock cycles to complete a current transaction before the channel is suspended.
}